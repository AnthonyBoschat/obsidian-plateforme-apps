# CLAUDE.md — Manuel de l'application Convertisseur

> Tous les chemins sont relatifs au dossier `Convertisseur/`, sauf dans le code, où ils sont écrits en entier.
> Dernière mise à jour : 25-10-2026.

## Fiche d'identité

| Élément | Valeur |
|---|---|
| Rôle | convertir des fichiers d'un format à un autre : images (dont HEIC), PDF, Word, notes, pages HTML, CSV, Excel, JSON |
| Version | 1.4 |
| Icône | arrow-right-left |
| Couleur | #f5a25d |
| Préfixe visuel | `cv` (styles injectés par `Système/Scripts/vue.js`, limités à la note de classe `cv`, au conteneur `.cv-app` et à la fenêtre `.cv-modale`) |
| Niveau d'IA | 1 programmatique (DataviewJS et bibliothèques JavaScript locales). Aucune fonction ne demande d'IA. |
| Données | `Inbox/`, `Convertis/`, `Originaux/` (tous trois exclus de Git), `Fonds/` |
| Sensibilité | normale |
| Point d'entrée | `Convertisseur.md` |
| Téléphone | partiel : toutes les conversions sauf celles vers PDF par impression (Word, note, HTML, tableaux), qui demandent le moteur d'impression de l'ordinateur. Pas de glisser-déposer. Les gros PDF sont lents. |
| Inbox | oui : tout fichier posé dans `Inbox/` apparaît dans la liste |
| Modifications `.obsidian` | aucune |
| Prérequis | `Système/prérequis.json` |

## Principe

- **Détection automatique** par le contenu du fichier (signature binaire), l'extension ne sert qu'en secours. Une archive ZIP est reconnue comme Word ou Excel selon ce qu'elle contient.
- Chaque fichier ne propose **que les formats possibles** pour son type.
- Tout tourne dans Obsidian, sans logiciel externe ni connexion : les bibliothèques sont dans `Système/Bibliothèques/` et ne sont chargées qu'à la première conversion qui en a besoin.
- **Originaux** : interrupteur « Conserver les originaux », désactivé par défaut (`Système/réglages.json`).
  - Désactivé : un original venu de l'Inbox part dans la corbeille d'Obsidian (`.trash`, récupérable). Un fichier choisi ou déposé depuis l'ordinateur reste où il était.
  - Activé : l'original de l'Inbox est déplacé dans `Originaux/`. Un fichier venu de l'ordinateur y est copié.
- Pas d'historique : la liste ne vit que pendant la session (« Retirer les terminés », croix pour retirer une ligne sans supprimer le fichier).
- **Supprimer un fichier converti** : icône corbeille sur une ligne terminée, puis « Supprimer ? Oui / Non ». Le résultat part dans la corbeille d'Obsidian (récupérable), avec son dossier « - pages » ou « - images » s'il en a un. Les lignes qui partageaient ce résultat (assemblage, fusion) quittent la liste avec lui.

## Conversions (version 1.2)

| Type détecté | Formats proposés |
|---|---|
| Image (PNG, JPG, WebP, GIF, BMP, AVIF, HEIC) | PNG, JPG, WebP, PDF, JPG allégé (1920 px de large, qualité 82 %) |
| Image vectorielle (SVG) | PNG, JPG, PDF (rendu à 1600 px de large au minimum) |
| PDF | images PNG ou JPG (une par page, dossier « <nom> - pages »), **Word (mise en page simplifiée)**, texte en note Markdown, extraire des pages (« 1-3, 5 »), tourner de 90°, **compresser (pages en images)** |
| Word (DOCX) | **PDF** (ordinateur), note Markdown (images dans « <nom> - images », intégrées avec `![[…]]`), HTML |
| Note (MD, TXT) | **PDF** (ordinateur), Word (DOCX), HTML, **EPUB** (propriétés retirées, liens internes remplacés par leur texte, images `![[…]]` intégrées dans PDF, HTML et EPUB, callouts en citations titrées) |
| Page HTML | **PDF** (ordinateur), note Markdown (scripts et styles retirés) |
| CSV | Excel (XLSX), JSON, **PDF (tableau, A4 paysage)** (séparateur `,` `;` ou tabulation détecté, nombres reconnus, zéros de tête gardés) |
| Excel (XLSX) | CSV (un fichier par feuille), JSON (une clé par feuille s'il y en a plusieurs), **PDF (une feuille par page)** |
| JSON | CSV, Excel (une feuille par clé si l'objet ne contient que des listes) |

- **Infobulle** au survol des onglets Images, Documents et Données : conversions possibles pour chaque type d'entrée, calculées depuis `getTargets` du moteur (donc toujours à jour, et sans les conversions par impression sur téléphone).
- **Actions groupées** (barre du haut) : « Assembler N images en un PDF » (ordre de la liste), « Fusionner N PDF ».
- **Images vers PDF** : une page A4 par image, orientée comme l'image, marges de 18 points, jamais agrandie au-delà de 96 points par pouce.
- **CSV produits** : séparateur `;`, virgule décimale, UTF-8 avec BOM, pour Excel en français.
- **Dates** : les dates Excel sont lues depuis leur numéro de série (`XLSX.SSF.parse_date_code`), jamais par `Date` (SheetJS 0.18.5 les recule d'une minute avec le fuseau de Paris). Sorties CSV et JSON en `AAAA-MM-JJ` ou `AAAA-MM-JJ HH:MM`. Une date `AAAA-MM-JJ` ou `JJ/MM/AAAA` d'un CSV devient une vraie date dans Excel (affichée jj/mm/aaaa).
- **JSON vers tableau** : sous-objets en colonnes `parent.enfant`, listes simples en « a, b, c ».
- **Non pris en charge** (ligne marquée, sans bouton) : PowerPoint, ZIP, JSON mal formé, PDF protégé par mot de passe.
- **Écartés** (pas assez fiables sans logiciel externe) : OCR, audio et vidéo, PowerPoint, Word vers PDF au rendu identique à Word.

### Conversions vers PDF par impression (ordinateur)

- Le HTML préparé est écrit dans un `<webview>` invisible (page `app://obsidian.md/help.html`), puis imprimé par `printToPDF` de Chromium. Le PDF obtenu garde le texte sélectionnable et les liens. Fonction `printHtmlToPdf` du moteur.
- **Word vers PDF** : docx-preview met en forme le contenu (styles, titres, listes, tableaux, images, polices, couleurs, notes de bas de page). Le contenu s'écoule de page en page avec le format et les marges de chaque section (règles `@page` nommées, sauts de page du document respectés). En-têtes et pieds de page par défaut sont relus dans le XML (texte, mise en forme simple, tabulations, images, champs « numéro de page » et « nombre de pages ») et imprimés sur chaque page par Chromium.
- Limites connues de Word vers PDF : la pagination est celle de Chromium (les coupures de page peuvent différer de Word), l'en-tête « première page » différente n'est pas repris, une section paysage sans saut de page avant elle reste au format de la précédente, zones de texte flottantes, SmartArt et équations peuvent bouger.
- Note et HTML : A4, marges de 18 à 20 mm. Tableaux : A4 paysage, une feuille Excel par page.

### PDF vers Word (mise en page simplifiée)

- Lignes reconstruites d'après la position du texte, paragraphes recollés (césures retirées), titres d'après la taille de police (trois niveaux), gras et italique d'après le nom de la police, listes à puces, tableaux d'après les colonnes alignées, images reprises à leur place, un saut de page par page.
- En-têtes, pieds de page et numéros répétés sur plusieurs pages sont retirés.
- Perdus : colonnes de texte, mise en page exacte, couleurs, cellules fusionnées. Un PDF scanné ne contient pas de texte (pas d'OCR).

## Structure

```
Convertisseur.md                entrée : cssclasses `cv`, appelle Système/Scripts/vue.js
CLAUDE.md
Inbox/                          données : fichiers à convertir (exclu de Git)
Convertis/                      données : résultats (exclu de Git)
Originaux/                      données : originaux conservés si l'interrupteur est activé (exclu de Git)
Fonds/                          données : images de fond (« Forêt dans la brume.jpg » copiée de Plateforme/Fonds)
Système/
    Scripts/vue.js              la vue (maquette C « Liste compacte »), fond et transparence, glisser-déposer, écriture des résultats
    Scripts/conversions.js      le moteur : détection et conversions, sans affichage ni écriture (renvoie { relativePath, data })
    Bibliothèques/              pdf-lib 1.17.1, pdf.js 3.11.174 (pdf.min.js et pdf.worker.min.js), mammoth 1.8.0,
                                SheetJS 0.18.5 (xlsx.min.js), docx 8.5.0, marked 12.0.2, turndown 7.2.0 et turndown-plugin-gfm 1.0.2,
                                docx-preview 0.3.3, JSZip 3.10.1, heic2any 0.0.4 (contient libheif), licences.txt
    apparence.json              fond, voile, assombrir, flou, teinte, réduire la transparence, accent
    réglages.json               conserverOriginaux (false par défaut)
    prérequis.json
    dossiers.json               couleurs des dossiers pour le Lanceur
```

## Scripts et pages

- `vue.js` lit `conversions.js` et l'exécute avec `new Function("app", "loadLibrary", code)` (le moteur se termine par un `return`).
- `loadLibrary(fichier, nomGlobal)` lit une bibliothèque et l'exécute avec `module`, `exports`, `define` et `require` masqués, pour que les modules universels (UMD) se déclarent comme dans un navigateur malgré Node dans Obsidian. Les bibliothèques chargées restent en mémoire (`window.cvBibliotheques`, une entrée par fichier, car docx et docx-preview déclarent tous deux le nom global `docx`).
- Le travailleur de pdf.js est chargé depuis `pdf.worker.min.js` sous forme d'URL de blob.
- Les noms de sortie ne remplacent jamais un fichier : « nom (2) », « nom (3) »…
- Ouvrir : notes, PDF et images dans un onglet d'Obsidian. Les autres formats (DOCX, XLSX, HTML, CSV, JSON) avec l'application par défaut de Windows.
- Le contexte de la vue (`window.cvContexte`) garde la liste tant qu'Obsidian reste ouvert.

## Visuel

- Maquette C « Liste compacte » (choisie le 25-10-2026, canevas « Convertisseur — maquettes ») : en-tête (logo, nom, zone de dépôt, relire l'Inbox, fond), carte liste (onglets Tous, Images, Documents, Données, actions groupées, « Tout convertir », une ligne par fichier), pied (interrupteur « Conserver les originaux », liens Convertis et Originaux).
- Accent `#f5a25d`. Pastilles de type : images bleu, PDF rouge, Word indigo, notes violet, données vert.
- Verre sans artefacts : le flou est porté par `::before` des cartes (`.cv-verre`), la liste ne défile pas dans la carte, la fenêtre « Fond et transparence » est opaque et sans flou.
- Largeur réduite (requête de conteneur, moins de 820 px) : la zone de dépôt passe sous le titre (« Choisir des fichiers »), chaque ligne passe sur deux ou trois rangées.
- Police Geist si installée, sinon Segoe UI, 13 px.

## Commandes de l'utilisateur

- « Ajoute la conversion X vers Y » : l'ajouter dans `conversions.js` (`TARGETS` et `convert`), déclarer toute nouvelle bibliothèque dans `prérequis.json` et ici.
- « Mets à jour les bibliothèques » : les retélécharger avec npm, remplacer les fichiers, tester chaque conversion.

## Garde-fous propres à l'application

- Tester chaque conversion modifiée avant de livrer, avec un faux `app` en mémoire : dans Chromium (Playwright) pour l'affichage et les conversions sans impression, dans Electron (sous `xvfb-run`, protocole `app://` simulé, `webviewTag` activé) pour les conversions vers PDF par impression.
- Ne jamais écrire en dehors de `Convertisseur/`.
- Ne jamais vider `Originaux/` ni la corbeille sans accord de l'utilisateur.

## Journal des modifications

| Version | Date | Changements |
|---|---|---|
| 1.4 | 25-10-2026 | Excel vers CSV et JSON : dates exactes (plus de recul d'une minute) et au format AAAA-MM-JJ, virgule décimale dans les CSV. CSV vers Excel : vraies dates. JSON vers tableau : sous-objets et listes aplatis |
| 1.3 | 25-10-2026 | infobulle des conversions possibles au survol des onglets Images, Documents et Données |
| 1.2 | 25-10-2026 | Word, note, page HTML, CSV et Excel vers PDF par le moteur d'impression d'Obsidian (Word : docx-preview, marges et format par section, en-têtes et pieds de page avec numéros). PDF vers Word simplifié (titres, listes, tableaux, images). Compression de PDF. Note vers EPUB. Photos HEIC. Page HTML vers note. Images `![[…]]` intégrées dans les sorties PDF, HTML et EPUB. Word vers PDF par défaut |
| 1.1 | 25-10-2026 | bouton corbeille sur chaque conversion terminée : supprime le fichier converti (et son dossier de pages ou d'images) après confirmation, vers la corbeille d'Obsidian |
| 1.0 | 25-10-2026 | création : détection automatique, conversions d'images, PDF, Word, notes et données, actions groupées, interrupteur « Conserver les originaux », maquette C « Liste compacte » avec fond et transparence |
