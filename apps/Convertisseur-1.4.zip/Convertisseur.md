---
cssclasses:
  - cv
---
```dataviewjs
await dv.view("Convertisseur/Système/Scripts/vue")
```
