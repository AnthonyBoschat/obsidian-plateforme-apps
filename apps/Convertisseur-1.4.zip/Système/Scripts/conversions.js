// Moteur du Convertisseur : détection du type de fichier et conversions, sans affichage.
// Chargé par vue.js avec new Function("app", "loadLibrary", code) : le fichier se termine par un return.
// Aucune écriture sur le disque ici : chaque conversion renvoie la liste des fichiers produits ({ relativePath, data }).

const POINTS_PER_PIXEL   = 0.75
const A4_WIDTH           = 595.28
const A4_HEIGHT          = 841.89
const PAGE_MARGIN        = 18
const PDF_RENDER_SCALE   = 2
const PDF_MAX_WIDTH      = 2480
const SVG_MIN_WIDTH      = 1600
const JPG_QUALITY        = 0.92
const WEBP_QUALITY       = 0.9
const LIGHT_MAX_WIDTH    = 1920
const LIGHT_JPG_QUALITY  = 0.82
const CSV_SEPARATOR      = ";"
const UTF8_BOM           = "﻿"
const SNIFF_TEXT_LENGTH  = 4096
const MONOSPACE_FONT     = "Consolas"
const DOCUMENT_FONT      = "Calibri"
const NUMBERING_NAME     = "cv-numeros"

const PRINT_PAGE_URL     = "app://obsidian.md/help.html"
const PRINT_TIMEOUT_MS   = 60000
const COMPRESS_DPI       = 150
const COMPRESS_QUALITY   = 0.7
const MIN_IMAGE_POINTS   = 24

const TARGETS = {
  image: [
    { id: "png",       label: "PNG",                   extension: "png",  suffix: "" },
    { id: "jpg",       label: "JPG",                   extension: "jpg",  suffix: "" },
    { id: "webp",      label: "WebP",                  extension: "webp", suffix: "" },
    { id: "pdf",       label: "PDF",                   extension: "pdf",  suffix: "" },
    { id: "jpg-leger", label: "JPG allégé (1920 px)",  extension: "jpg",  suffix: " - allégé" }
  ],
  svg: [
    { id: "png", label: "PNG", extension: "png", suffix: "" },
    { id: "jpg", label: "JPG", extension: "jpg", suffix: "" },
    { id: "pdf", label: "PDF", extension: "pdf", suffix: "" }
  ],
  pdf: [
    { id: "pages-png",  label: "Images PNG (une par page)",          extension: "png",  suffix: "" },
    { id: "pages-jpg",  label: "Images JPG (une par page)",          extension: "jpg",  suffix: "" },
    { id: "docx",       label: "Word (mise en page simplifiée)",     extension: "docx", suffix: "" },
    { id: "texte",      label: "Texte (note)",                       extension: "md",   suffix: "" },
    { id: "extraire",   label: "Extraire des pages…",                extension: "pdf",  suffix: " - extrait" },
    { id: "tourner",    label: "Tourner de 90°",                     extension: "pdf",  suffix: " - tourné" },
    { id: "compresser", label: "Compresser (pages en images)",       extension: "pdf",  suffix: " - compressé" }
  ],
  word: [
    { id: "pdf",  label: "PDF",           extension: "pdf",  suffix: "", needsPrint: true },
    { id: "note", label: "Note Markdown", extension: "md",   suffix: "" },
    { id: "html", label: "HTML",          extension: "html", suffix: "" }
  ],
  note: [
    { id: "pdf",  label: "PDF",         extension: "pdf",  suffix: "", needsPrint: true },
    { id: "docx", label: "Word (DOCX)", extension: "docx", suffix: "" },
    { id: "html", label: "HTML",        extension: "html", suffix: "" },
    { id: "epub", label: "EPUB (liseuse)", extension: "epub", suffix: "" }
  ],
  html: [
    { id: "pdf",  label: "PDF",           extension: "pdf", suffix: "", needsPrint: true },
    { id: "note", label: "Note Markdown", extension: "md",  suffix: "" }
  ],
  csv: [
    { id: "xlsx", label: "Excel (XLSX)",  extension: "xlsx", suffix: "" },
    { id: "json", label: "JSON",          extension: "json", suffix: "" },
    { id: "pdf",  label: "PDF (tableau)", extension: "pdf",  suffix: "", needsPrint: true }
  ],
  xlsx: [
    { id: "csv",  label: "CSV",           extension: "csv",  suffix: "" },
    { id: "json", label: "JSON",          extension: "json", suffix: "" },
    { id: "pdf",  label: "PDF (tableau)", extension: "pdf",  suffix: "", needsPrint: true }
  ],
  json: [
    { id: "csv",  label: "CSV",          extension: "csv",  suffix: "" },
    { id: "xlsx", label: "Excel (XLSX)", extension: "xlsx", suffix: "" }
  ]
}

const DEFAULT_TARGET = {
  png: "jpg", jpg: "pdf", webp: "jpg", gif: "png", bmp: "png", avif: "jpg", heic: "jpg",
  svg: "png", pdf: "pages-png", word: "pdf", note: "pdf", html: "pdf", csv: "xlsx", xlsx: "csv", json: "xlsx"
}

const IMAGE_MIME = { png: "image/png", jpg: "image/jpeg", webp: "image/webp", gif: "image/gif", bmp: "image/bmp", avif: "image/avif", heic: "image/heic" }
const EMBED_IMAGE_EXTENSIONS = ["png", "jpg", "jpeg", "gif", "webp", "svg", "bmp", "avif"]


// ---------- Outils communs ----------

function getExtension(name) {
  const parts = String(name).split(".")
  if (parts.length < 2) return ""
  return parts.pop().toLowerCase()
}


function startsWithBytes(bytes, signature, offset) {
  const start = offset ?? 0
  return signature.every((value, index) => bytes[start + index] === value)
}


function decodeText(bytes) {
  const utf8Text      = new TextDecoder("utf-8").decode(bytes)
  const brokenCount   = (utf8Text.match(/�/g) ?? []).length
  const looksBroken   = brokenCount > 3
  const decodedText   = looksBroken ? new TextDecoder("windows-1252").decode(bytes) : utf8Text
  const withoutBom    = decodedText.replace(/^﻿/, "")
  return withoutBom
}


function encodeText(text) {
  return new TextEncoder().encode(text)
}


function toBlob(bytes, mime) {
  return new Blob([bytes], { type: mime })
}


async function blobToBytes(blob) {
  const buffer = await blob.arrayBuffer()
  return new Uint8Array(buffer)
}


function padNumber(value, width) {
  return String(value).padStart(width, "0")
}


function escapeHtml(text) {
  const value = String(text ?? "")
  return value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;")
}


function unescapeEntities(text) {
  const value = String(text ?? "")
  return value.replace(/&quot;/g, "\"").replace(/&#39;/g, "'").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&amp;/g, "&")
}


// ---------- Détection ----------

function detectFromSignature(bytes) {
  if (startsWithBytes(bytes, [0x89, 0x50, 0x4E, 0x47])) return "png"
  if (startsWithBytes(bytes, [0xFF, 0xD8, 0xFF]))       return "jpg"
  if (startsWithBytes(bytes, [0x47, 0x49, 0x46, 0x38])) return "gif"
  if (startsWithBytes(bytes, [0x25, 0x50, 0x44, 0x46])) return "pdf"
  if (startsWithBytes(bytes, [0x50, 0x4B, 0x03, 0x04])) return "zip"
  const isRiff = startsWithBytes(bytes, [0x52, 0x49, 0x46, 0x46])
  const isWebp = startsWithBytes(bytes, [0x57, 0x45, 0x42, 0x50], 8)
  if (isRiff && isWebp) return "webp"
  const hasFileType = startsWithBytes(bytes, [0x66, 0x74, 0x79, 0x70], 4)
  if (hasFileType) {
    const brand = new TextDecoder("latin1").decode(bytes.slice(8, 12))
    if (brand === "avif" || brand === "avis") return "avif"
    if (["heic", "heix", "mif1", "msf1"].includes(brand)) return "heic"
  }
  return null
}


function detectZipContent(bytes) {
  const content = new TextDecoder("latin1").decode(bytes)
  if (content.includes("word/document.xml")) return "word"
  if (content.includes("xl/workbook.xml"))   return "xlsx"
  if (content.includes("ppt/presentation"))  return "pptx"
  return "zip"
}


function detectText(bytes, extension) {
  const sample  = new TextDecoder("utf-8").decode(bytes.slice(0, SNIFF_TEXT_LENGTH))
  const trimmed = sample.replace(/^﻿/, "").trimStart()
  if (sample.includes("\u0000")) return null
  const isSvg = trimmed.startsWith("<svg") || (trimmed.startsWith("<?xml") && trimmed.includes("<svg"))
  if (isSvg || extension === "svg") return "svg"
  const lowered = trimmed.slice(0, 200).toLowerCase()
  const isHtml  = ["html", "htm"].includes(extension) || lowered.startsWith("<!doctype html") || lowered.startsWith("<html")
  if (isHtml) return "html"
  if (["md", "markdown", "txt"].includes(extension)) return "note"
  if (["csv", "tsv"].includes(extension)) return "csv"
  const looksJson = extension === "json" || trimmed.startsWith("{") || trimmed.startsWith("[")
  if (looksJson) {
    try {
      JSON.parse(decodeText(bytes))
      return "json"
    } catch (error) {
      if (extension === "json") return "json-invalide"
    }
  }
  return null
}


function detectKind(bytes, name) {
  const extension = getExtension(name)
  const signature = detectFromSignature(bytes)
  const UNSUPPORTED = {
    pptx: "Présentation PowerPoint : pas encore prise en charge.",
    zip:  "Archive ZIP : pas de conversion possible.",
    "json-invalide": "Fichier JSON mal formé."
  }
  if (["png", "jpg", "gif", "webp", "avif", "heic"].includes(signature)) return { kind: "image", format: signature }
  if (signature === "pdf") return { kind: "pdf", format: "pdf" }
  if (signature === "zip") {
    const content = detectZipContent(bytes)
    if (content === "word") return { kind: "word", format: "word" }
    if (content === "xlsx") return { kind: "xlsx", format: "xlsx" }
    return { kind: "inconnu", format: content, message: UNSUPPORTED[content] }
  }
  const isBitmap = startsWithBytes(bytes, [0x42, 0x4D]) && ["bmp", "dib"].includes(extension)
  if (isBitmap) return { kind: "image", format: "bmp" }
  const textKind = detectText(bytes, extension)
  if (textKind === "json-invalide") return { kind: "inconnu", format: "json", message: UNSUPPORTED["json-invalide"] }
  if (textKind === "svg") return { kind: "svg", format: "svg" }
  if (textKind) return { kind: textKind, format: textKind }
  return { kind: "inconnu", format: extension || "?", message: "Type de fichier non reconnu." }
}


function canPrintPdf() {
  const isElectron = Boolean(window.process && window.process.versions && window.process.versions.electron)
  return isElectron
}


function getTargets(detection) {
  const targets   = TARGETS[detection.kind] ?? []
  const printable = canPrintPdf()
  const available = targets.filter(target => !(detection.kind === "image" && target.id === detection.format) && (printable || !target.needsPrint))
  return available
}


function getDefaultTarget(detection) {
  const targets   = getTargets(detection)
  const preferred = DEFAULT_TARGET[detection.format] ?? DEFAULT_TARGET[detection.kind]
  const found     = targets.find(target => target.id === preferred)
  return found ? found.id : (targets[0]?.id ?? null)
}


async function describe(bytes, detection) {
  try {
    if (detection.format === "heic") return "Photo HEIC"
    if (detection.kind === "image") {
      const bitmap = await createImageBitmap(toBlob(bytes, IMAGE_MIME[detection.format]))
      const text   = bitmap.width + " × " + bitmap.height
      bitmap.close()
      return text
    }
    if (detection.kind === "pdf") {
      const PDFLib   = await loadLibrary("pdf-lib.min.js", "PDFLib")
      const document = await PDFLib.PDFDocument.load(bytes, { ignoreEncryption: true, updateMetadata: false })
      const count    = document.getPageCount()
      const locked   = document.isEncrypted ? " · protégé" : ""
      return count + (count > 1 ? " pages" : " page") + locked
    }
    if (detection.kind === "csv") {
      const rows = parseCsv(decodeText(bytes))
      return rows.length + " lignes"
    }
    if (detection.kind === "json") {
      const data  = JSON.parse(decodeText(bytes))
      const count = Array.isArray(data) ? data.length + " éléments" : Object.keys(data).length + " clés"
      return count
    }
  } catch (error) {
    return ""
  }
  return ""
}


// ---------- Images ----------

function loadImageElement(url) {
  return new Promise((resolve, reject) => {
    const image   = new Image()
    image.onload  = () => resolve(image)
    image.onerror = () => reject(new Error("Image illisible."))
    image.src     = url
  })
}


function prepareSvgText(text) {
  const parser   = new DOMParser()
  const document = parser.parseFromString(text, "image/svg+xml")
  const svg      = document.documentElement
  const viewBox  = (svg.getAttribute("viewBox") ?? "").split(/[\s,]+/).map(Number)
  const hasWidth = svg.hasAttribute("width") && !String(svg.getAttribute("width")).includes("%")
  if (!hasWidth && viewBox.length === 4) {
    svg.setAttribute("width", String(viewBox[2]))
    svg.setAttribute("height", String(viewBox[3]))
  }
  return new XMLSerializer().serializeToString(svg)
}


async function decodeBitmap(bytes, format) {
  if (format !== "heic") return createImageBitmap(toBlob(bytes, IMAGE_MIME[format]))
  const heic2any = await loadLibrary("heic2any.min.js", "heic2any")
  const decoded  = await heic2any({ blob: toBlob(bytes, IMAGE_MIME.heic), toType: "image/png" })
  const firstImage = Array.isArray(decoded) ? decoded[0] : decoded
  return createImageBitmap(firstImage)
}


async function rasterize(bytes, detection, opaque) {
  const canvas  = document.createElement("canvas")
  const context = canvas.getContext("2d")
  if (detection.kind === "svg") {
    const svgText = prepareSvgText(decodeText(bytes))
    const url     = URL.createObjectURL(toBlob(encodeText(svgText), "image/svg+xml"))
    try {
      const image   = await loadImageElement(url)
      const width   = image.naturalWidth || 1024
      const height  = image.naturalHeight || 1024
      const scale   = width < SVG_MIN_WIDTH ? SVG_MIN_WIDTH / width : 1
      canvas.width  = Math.round(width * scale)
      canvas.height = Math.round(height * scale)
      if (opaque) { context.fillStyle = "#ffffff"; context.fillRect(0, 0, canvas.width, canvas.height) }
      context.drawImage(image, 0, 0, canvas.width, canvas.height)
    } finally {
      URL.revokeObjectURL(url)
    }
    return canvas
  }
  const bitmap  = await decodeBitmap(bytes, detection.format)
  canvas.width  = bitmap.width
  canvas.height = bitmap.height
  if (opaque) { context.fillStyle = "#ffffff"; context.fillRect(0, 0, canvas.width, canvas.height) }
  context.drawImage(bitmap, 0, 0)
  bitmap.close()
  return canvas
}


function shrinkCanvas(canvas, maxWidth) {
  if (canvas.width <= maxWidth) return canvas
  const ratio   = maxWidth / canvas.width
  const smaller = document.createElement("canvas")
  smaller.width  = maxWidth
  smaller.height = Math.round(canvas.height * ratio)
  const context = smaller.getContext("2d")
  context.imageSmoothingQuality = "high"
  context.drawImage(canvas, 0, 0, smaller.width, smaller.height)
  return smaller
}


function canvasToBytes(canvas, mime, quality) {
  return new Promise((resolve, reject) => {
    canvas.toBlob(async blob => {
      if (!blob) { reject(new Error("Conversion de l'image impossible.")); return }
      resolve(await blobToBytes(blob))
    }, mime, quality)
  })
}


async function prepareImageForPdf(bytes, detection) {
  if (detection.format === "png" || detection.format === "jpg") {
    const bitmap = await createImageBitmap(toBlob(bytes, IMAGE_MIME[detection.format]))
    const result = { bytes, format: detection.format, width: bitmap.width, height: bitmap.height }
    bitmap.close()
    return result
  }
  const canvas   = await rasterize(bytes, detection, true)
  const jpgBytes = await canvasToBytes(canvas, "image/jpeg", JPG_QUALITY)
  return { bytes: jpgBytes, format: "jpg", width: canvas.width, height: canvas.height }
}


async function imagesToPdf(preparedImages) {
  const PDFLib   = await loadLibrary("pdf-lib.min.js", "PDFLib")
  const document = await PDFLib.PDFDocument.create()
  for (const image of preparedImages) {
    const embedded    = image.format === "png" ? await document.embedPng(image.bytes) : await document.embedJpg(image.bytes)
    const landscape   = image.width > image.height
    const pageWidth   = landscape ? A4_HEIGHT : A4_WIDTH
    const pageHeight  = landscape ? A4_WIDTH : A4_HEIGHT
    const usableWidth = pageWidth - PAGE_MARGIN * 2
    const usableHeight = pageHeight - PAGE_MARGIN * 2
    const naturalWidth = image.width * POINTS_PER_PIXEL
    const scale       = Math.min(usableWidth / image.width, usableHeight / image.height, naturalWidth / image.width)
    const drawWidth   = image.width * scale
    const drawHeight  = image.height * scale
    const page        = document.addPage([pageWidth, pageHeight])
    page.drawImage(embedded, { x: (pageWidth - drawWidth) / 2, y: (pageHeight - drawHeight) / 2, width: drawWidth, height: drawHeight })
  }
  return document.save()
}


async function convertImage(bytes, detection, target, baseName) {
  const outputName = baseName + "." + target.extension
  if (target.id === "pdf") {
    const prepared = await prepareImageForPdf(bytes, detection)
    const pdfBytes = await imagesToPdf([prepared])
    return [{ relativePath: outputName, data: pdfBytes }]
  }
  const opaque  = target.extension === "jpg"
  const canvas  = await rasterize(bytes, detection, opaque)
  if (target.id === "jpg-leger") {
    const smaller   = shrinkCanvas(canvas, LIGHT_MAX_WIDTH)
    const jpgBytes  = await canvasToBytes(smaller, "image/jpeg", LIGHT_JPG_QUALITY)
    return [{ relativePath: outputName, data: jpgBytes }]
  }
  const mime    = target.extension === "jpg" ? "image/jpeg" : "image/" + target.extension
  const quality = target.extension === "webp" ? WEBP_QUALITY : JPG_QUALITY
  const result  = await canvasToBytes(canvas, mime, quality)
  return [{ relativePath: outputName, data: result }]
}


async function assembleImages(items, baseName) {
  const prepared = []
  for (const item of items) {
    const image = await prepareImageForPdf(item.bytes, item.detection)
    prepared.push(image)
  }
  const pdfBytes = await imagesToPdf(prepared)
  return [{ relativePath: baseName + ".pdf", data: pdfBytes }]
}


// ---------- PDF ----------

async function loadPdfJs() {
  const pdfjsLib = await loadLibrary("pdf.min.js", "pdfjsLib")
  if (!pdfjsLib.GlobalWorkerOptions.workerSrc) {
    const workerCode = await app.vault.adapter.read(LIBRARY_PATH + "/pdf.worker.min.js")
    const workerUrl  = URL.createObjectURL(new Blob([workerCode], { type: "text/javascript" }))
    pdfjsLib.GlobalWorkerOptions.workerSrc = workerUrl
  }
  return pdfjsLib
}


async function openPdfForReading(bytes) {
  const pdfjsLib = await loadPdfJs()
  const copy     = bytes.slice(0)
  const task     = pdfjsLib.getDocument({ data: copy, isEvalSupported: false })
  try {
    return await task.promise
  } catch (error) {
    if (error && error.name === "PasswordException") throw new Error("PDF protégé par mot de passe.")
    throw error
  }
}


async function pdfToImages(bytes, target, baseName, onProgress) {
  const document  = await openPdfForReading(bytes)
  const pageCount = document.numPages
  const mime      = target.extension === "jpg" ? "image/jpeg" : "image/png"
  const outputs   = []
  for (let pageNumber = 1; pageNumber <= pageCount; pageNumber++) {
    const page      = await document.getPage(pageNumber)
    const natural   = page.getViewport({ scale: 1 })
    const scale     = Math.min(PDF_RENDER_SCALE, PDF_MAX_WIDTH / natural.width)
    const viewport  = page.getViewport({ scale })
    const canvas    = window.document.createElement("canvas")
    canvas.width    = Math.round(viewport.width)
    canvas.height   = Math.round(viewport.height)
    const context   = canvas.getContext("2d")
    context.fillStyle = "#ffffff"
    context.fillRect(0, 0, canvas.width, canvas.height)
    await page.render({ canvasContext: context, viewport }).promise
    const imageBytes = await canvasToBytes(canvas, mime, JPG_QUALITY)
    const pageLabel  = padNumber(pageNumber, String(pageCount).length < 2 ? 2 : String(pageCount).length)
    const fileName   = pageCount === 1 ? baseName + "." + target.extension : baseName + " - pages/" + baseName + " - page " + pageLabel + "." + target.extension
    outputs.push({ relativePath: fileName, data: imageBytes })
    page.cleanup()
    onProgress(pageNumber / pageCount, "Page " + pageNumber + " sur " + pageCount)
  }
  await document.destroy()
  return outputs
}


async function pdfToText(bytes, baseName, onProgress) {
  const document  = await openPdfForReading(bytes)
  const pageCount = document.numPages
  const sections  = ["# " + baseName, ""]
  for (let pageNumber = 1; pageNumber <= pageCount; pageNumber++) {
    const page    = await document.getPage(pageNumber)
    const content = await page.getTextContent()
    const text    = content.items.map(item => (item.str ?? "") + (item.hasEOL ? "\n" : "")).join("")
    const cleaned = text.replace(/[ \t]+\n/g, "\n").replace(/\n{3,}/g, "\n\n").trim()
    sections.push("## Page " + pageNumber, "", cleaned || "*(page sans texte : probablement une image scannée)*", "")
    onProgress(pageNumber / pageCount, "Page " + pageNumber + " sur " + pageCount)
  }
  await document.destroy()
  const markdown = sections.join("\n")
  return [{ relativePath: baseName + ".md", data: markdown }]
}


function parsePageRanges(text, pageCount) {
  const parts   = String(text ?? "").split(/[,;]/).map(part => part.trim()).filter(Boolean)
  const indexes = []
  for (const part of parts) {
    const match = part.match(/^(\d+)\s*(?:-\s*(\d+))?$/)
    if (!match) throw new Error("Pages à écrire comme « 1-3, 5 ».")
    const first = Number(match[1])
    const last  = match[2] ? Number(match[2]) : first
    if (first < 1 || last > pageCount || first > last) throw new Error("Pages hors du document (1 à " + pageCount + ").")
    for (let page = first; page <= last; page++) indexes.push(page - 1)
  }
  if (indexes.length === 0) throw new Error("Indiquer les pages à extraire, par exemple « 1-3, 5 ».")
  return indexes
}


async function loadPdfForEditing(bytes) {
  const PDFLib   = await loadLibrary("pdf-lib.min.js", "PDFLib")
  const document = await PDFLib.PDFDocument.load(bytes, { ignoreEncryption: true })
  if (document.isEncrypted) throw new Error("PDF protégé par mot de passe.")
  return { PDFLib, document }
}


async function extractPages(bytes, pagesText, baseName) {
  const { PDFLib, document } = await loadPdfForEditing(bytes)
  const indexes = parsePageRanges(pagesText, document.getPageCount())
  const result  = await PDFLib.PDFDocument.create()
  const copied  = await result.copyPages(document, indexes)
  copied.forEach(page => result.addPage(page))
  const pdfBytes = await result.save()
  return [{ relativePath: baseName + ".pdf", data: pdfBytes }]
}


async function rotatePdf(bytes, baseName) {
  const { PDFLib, document } = await loadPdfForEditing(bytes)
  const QUARTER_TURN = 90
  for (const page of document.getPages()) {
    const current = page.getRotation().angle
    page.setRotation(PDFLib.degrees((current + QUARTER_TURN) % 360))
  }
  const pdfBytes = await document.save()
  return [{ relativePath: baseName + ".pdf", data: pdfBytes }]
}


async function mergePdfs(items, baseName) {
  const PDFLib = await loadLibrary("pdf-lib.min.js", "PDFLib")
  const result = await PDFLib.PDFDocument.create()
  for (const item of items) {
    const { document } = await loadPdfForEditing(item.bytes)
    const copied = await result.copyPages(document, document.getPageIndices())
    copied.forEach(page => result.addPage(page))
  }
  const pdfBytes = await result.save()
  return [{ relativePath: baseName + ".pdf", data: pdfBytes }]
}


// ---------- Word et notes ----------

function htmlDocument(title, body) {
  const STYLE = "body{font-family:Segoe UI,system-ui,sans-serif;max-width:820px;margin:40px auto;padding:0 20px;line-height:1.6;color:#1d1f23}img{max-width:100%}table{border-collapse:collapse}td,th{border:1px solid #ccc;padding:6px 10px}pre{background:#f4f4f4;padding:12px;overflow:auto}code{font-family:Consolas,monospace}"
  return "<!doctype html>\n<html lang=\"fr\">\n<head>\n<meta charset=\"utf-8\">\n<title>" + escapeHtml(title) + "</title>\n<style>" + STYLE + "</style>\n</head>\n<body>\n" + body + "\n</body>\n</html>\n"
}


async function readMammothImage(image) {
  const data = await image.read()
  if (data instanceof Uint8Array) return data
  if (data instanceof ArrayBuffer) return new Uint8Array(data)
  return new Uint8Array(data.buffer ?? data)
}


async function wordToNote(bytes, baseName, outputFolder) {
  const mammoth           = await loadLibrary("mammoth.min.js", "mammoth")
  const TurndownService   = await loadLibrary("turndown.js", "TurndownService")
  const turndownPluginGfm = await loadLibrary("turndown-gfm.js", "turndownPluginGfm")
  const outputs           = []
  const imageFolder       = baseName + " - images"
  let imageCount          = 0
  const convertImage = mammoth.images.imgElement(async image => {
    imageCount++
    const extension    = (image.contentType.split("/")[1] ?? "png").replace("jpeg", "jpg").replace("svg+xml", "svg")
    const relativePath = imageFolder + "/image " + padNumber(imageCount, 2) + "." + extension
    const data         = await readMammothImage(image)
    outputs.push({ relativePath, data })
    return { src: "cv-image:" + relativePath }
  })
  const buffer    = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength)
  const converted = await mammoth.convertToHtml({ arrayBuffer: buffer }, { convertImage })
  const turndown  = new TurndownService({ headingStyle: "atx", codeBlockStyle: "fenced", bulletListMarker: "-", emDelimiter: "*" })
  turndown.use(turndownPluginGfm.gfm)
  turndown.addRule("images-obsidian", {
    filter: "img",
    replacement: (content, node) => {
      const source = node.getAttribute("src") ?? ""
      if (source.startsWith("cv-image:")) return "![[" + outputFolder + "/" + source.slice("cv-image:".length) + "]]"
      return "![](" + source + ")"
    }
  })
  turndown.addRule("listes-compactes", {
    filter: "li",
    replacement: (content, node, options) => {
      const parent      = node.parentNode
      const isOrdered   = parent.nodeName === "OL"
      const start       = Number(parent.getAttribute("start") ?? 1)
      const position    = Array.prototype.indexOf.call(parent.children, node)
      const prefix      = isOrdered ? (start + position) + ". " : options.bulletListMarker + " "
      const indentation = " ".repeat(prefix.length)
      const trimmed     = content.replace(/^\n+/, "").replace(/\n+$/, "\n")
      const indented    = trimmed.replace(/\n(?=.)/g, "\n" + indentation)
      const needsBreak  = node.nextSibling && !/\n$/.test(indented)
      return prefix + indented + (needsBreak ? "\n" : "")
    }
  })
  const markdown = turndown.turndown(converted.value).trim() + "\n"
  outputs.unshift({ relativePath: baseName + ".md", data: markdown })
  return outputs
}


async function wordToHtml(bytes, baseName) {
  const mammoth   = await loadLibrary("mammoth.min.js", "mammoth")
  const buffer    = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength)
  const converted = await mammoth.convertToHtml({ arrayBuffer: buffer })
  const page      = htmlDocument(baseName, converted.value)
  return [{ relativePath: baseName + ".html", data: page }]
}


function cleanObsidianMarkdown(text) {
  const withoutFrontmatter = text.replace(/^---\r?\n[\s\S]*?\r?\n---\r?\n/, "")
  const withoutEmbeds      = withoutFrontmatter.replace(/!\[\[([^\]|]+)(\|[^\]]*)?\]\]/g, "*(pièce jointe : $1)*")
  const withAliases        = withoutEmbeds.replace(/\[\[[^\]|]+\|([^\]]+)\]\]/g, "$1")
  const withLinks          = withAliases.replace(/\[\[([^\]]+)\]\]/g, "$1")
  const withHighlights     = withLinks.replace(/==([^=]+)==/g, "**$1**")
  const withCallouts       = withHighlights.replace(/^(>\s*)\[!([\w-]+)\][+-]?[ \t]*(.*)$/gm, (line, prefix, type, title) => prefix + "**" + (title.trim() || type.charAt(0).toUpperCase() + type.slice(1)) + "**")
  return withCallouts
}


async function noteToHtml(bytes, baseName, sourcePath) {
  const marked   = await loadLibrary("marked.min.js", "marked")
  const text     = decodeText(bytes).replace(/^---\r?\n[\s\S]*?\r?\n---\r?\n/, "")
  const resolved = await resolveEmbeds(text, sourcePath, "data")
  const markdown = cleanObsidianMarkdown(resolved.markdown)
  const body     = marked.parse(markdown, { gfm: true })
  const page     = htmlDocument(baseName, body)
  return [{ relativePath: baseName + ".html", data: page }]
}


function inlineRuns(docx, tokens, style) {
  const runs = []
  for (const token of tokens ?? []) {
    if (token.type === "strong")   { runs.push(...inlineRuns(docx, token.tokens, Object.assign({}, style, { bold: true }))); continue }
    if (token.type === "em")       { runs.push(...inlineRuns(docx, token.tokens, Object.assign({}, style, { italics: true }))); continue }
    if (token.type === "del")      { runs.push(...inlineRuns(docx, token.tokens, Object.assign({}, style, { strike: true }))); continue }
    if (token.type === "codespan") { runs.push(new docx.TextRun(Object.assign({}, style, { text: unescapeEntities(token.text), font: MONOSPACE_FONT }))); continue }
    if (token.type === "br")       { runs.push(new docx.TextRun({ text: "", break: 1 })); continue }
    if (token.type === "link") {
      const children = inlineRuns(docx, token.tokens, Object.assign({}, style, { style: "Hyperlink" }))
      runs.push(new docx.ExternalHyperlink({ link: token.href, children }))
      continue
    }
    if (token.type === "image")    { runs.push(new docx.TextRun(Object.assign({}, style, { text: "[image : " + (token.text || token.href) + "]", italics: true }))); continue }
    if (token.type === "html")     { runs.push(new docx.TextRun(Object.assign({}, style, { text: token.text.replace(/<[^>]+>/g, "") }))); continue }
    if (token.tokens && token.tokens.length) { runs.push(...inlineRuns(docx, token.tokens, style)); continue }
    runs.push(new docx.TextRun(Object.assign({}, style, { text: unescapeEntities(token.text ?? token.raw ?? "") })))
  }
  return runs
}


function blockParagraphs(docx, tokens, context) {
  const blocks = []
  for (const token of tokens ?? []) {
    const indent = context.indent ? { left: context.indent } : undefined
    if (token.type === "space") continue
    if (token.type === "heading") {
      const level = docx.HeadingLevel["HEADING_" + Math.min(token.depth, 6)]
      blocks.push(new docx.Paragraph({ heading: level, children: inlineRuns(docx, token.tokens, {}) }))
      continue
    }
    if (token.type === "paragraph" || token.type === "text") {
      blocks.push(new docx.Paragraph({ indent, children: inlineRuns(docx, token.tokens ?? [token], context.style ?? {}) }))
      continue
    }
    if (token.type === "list") {
      context.listInstance++
      const instance = context.listInstance
      for (const item of token.items) {
        const checkbox  = item.task ? (item.checked ? "☑ " : "☐ ") : ""
        const textToken = item.tokens.filter(child => child.type !== "list")
        const nested    = item.tokens.filter(child => child.type === "list")
        const runs      = [new docx.TextRun(checkbox), ...textToken.flatMap(child => inlineRuns(docx, child.tokens ?? [child], {}))]
        const numbering = token.ordered ? { numbering: { reference: NUMBERING_NAME, level: context.listLevel, instance } } : { bullet: { level: context.listLevel } }
        blocks.push(new docx.Paragraph(Object.assign({ children: runs }, numbering)))
        const nestedContext = Object.assign({}, context, { listLevel: Math.min(context.listLevel + 1, 8) })
        blocks.push(...blockParagraphs(docx, nested, nestedContext))
        context.listInstance = nestedContext.listInstance
      }
      continue
    }
    if (token.type === "code") {
      for (const line of token.text.split("\n")) {
        blocks.push(new docx.Paragraph({ indent, children: [new docx.TextRun({ text: line, font: MONOSPACE_FONT, size: 20 })] }))
      }
      continue
    }
    if (token.type === "blockquote") {
      const quoteContext = Object.assign({}, context, { indent: (context.indent ?? 0) + 720, style: { italics: true } })
      blocks.push(...blockParagraphs(docx, token.tokens, quoteContext))
      context.listInstance = quoteContext.listInstance
      continue
    }
    if (token.type === "table") {
      const makeCell = cell => new docx.TableCell({ children: [new docx.Paragraph({ children: inlineRuns(docx, cell.tokens, {}) })] })
      const header   = new docx.TableRow({ tableHeader: true, children: token.header.map(makeCell) })
      const rows     = token.rows.map(row => new docx.TableRow({ children: row.map(makeCell) }))
      blocks.push(new docx.Table({ width: { size: 100, type: docx.WidthType.PERCENTAGE }, rows: [header, ...rows] }))
      blocks.push(new docx.Paragraph({ children: [] }))
      continue
    }
    if (token.type === "hr") {
      blocks.push(new docx.Paragraph({ thematicBreak: true, children: [] }))
      continue
    }
    if (token.type === "html") {
      const text = token.text.replace(/<[^>]+>/g, "").trim()
      if (text) blocks.push(new docx.Paragraph({ children: [new docx.TextRun(text)] }))
    }
  }
  return blocks
}


async function noteToDocx(bytes, baseName) {
  const marked    = await loadLibrary("marked.min.js", "marked")
  const docx      = await loadLibrary("docx.js", "docx")
  const markdown  = cleanObsidianMarkdown(decodeText(bytes))
  const tokens    = marked.lexer(markdown, { gfm: true })
  const context   = { listLevel: 0, listInstance: 0 }
  const children  = blockParagraphs(docx, tokens, context)
  const levels    = Array.from({ length: 9 }, (unused, level) => ({ level, format: docx.LevelFormat.DECIMAL, text: "%" + (level + 1) + ".", alignment: docx.AlignmentType.START, style: { paragraph: { indent: { left: 720 * (level + 1), hanging: 360 } } } }))
  const document  = new docx.Document({
    creator: "Convertisseur",
    title: baseName,
    styles: { default: { document: { run: { font: DOCUMENT_FONT, size: 22 } } } },
    numbering: { config: [{ reference: NUMBERING_NAME, levels }] },
    sections: [{ children }]
  })
  const blob      = await docx.Packer.toBlob(document)
  const docxBytes = await blobToBytes(blob)
  return [{ relativePath: baseName + ".docx", data: docxBytes }]
}


// ---------- Données ----------

function detectSeparator(firstLine) {
  const candidates = [",", ";", "\t"]
  const counts     = candidates.map(separator => firstLine.split(separator).length)
  const best       = counts.indexOf(Math.max(...counts))
  return candidates[best]
}


function parseCsv(text) {
  const firstLine = text.split(/\r?\n/)[0] ?? ""
  const separator = detectSeparator(firstLine)
  const rows      = []
  let row         = []
  let cell        = ""
  let quoted      = false
  for (let index = 0; index < text.length; index++) {
    const character = text[index]
    const next      = text[index + 1]
    if (quoted) {
      if (character === "\"" && next === "\"") { cell += "\""; index++; continue }
      if (character === "\"") { quoted = false; continue }
      cell += character
      continue
    }
    if (character === "\"") { quoted = true; continue }
    if (character === separator) { row.push(cell); cell = ""; continue }
    if (character === "\r") continue
    if (character === "\n") { row.push(cell); rows.push(row); row = []; cell = ""; continue }
    cell += character
  }
  if (cell !== "" || row.length) { row.push(cell); rows.push(row) }
  const nonEmpty = rows.filter(line => line.some(value => value !== ""))
  return nonEmpty
}


// Date écrite « 2026-10-25 » ou « 25/10/2026 » : vraie date pour Excel (affichée jj/mm/aaaa).
function typeDate(value) {
  const text    = String(value).trim()
  const isoDate = text.match(/^(\d{4})-(\d{2})-(\d{2})$/)
  const frDate  = text.match(/^(\d{2})\/(\d{2})\/(\d{4})$/)
  const parts   = isoDate ? [isoDate[1], isoDate[2], isoDate[3]] : frDate ? [frDate[3], frDate[2], frDate[1]] : null
  if (!parts) return null
  const date    = new Date(Number(parts[0]), Number(parts[1]) - 1, Number(parts[2]), 12)
  const valid   = date.getMonth() === Number(parts[1]) - 1 && date.getDate() === Number(parts[2])
  return valid ? date : null
}


function typeValue(value) {
  const text       = String(value).trim()
  const isNumber   = /^-?\d+([.,]\d+)?$/.test(text)
  const hasLeading = /^-?0\d/.test(text)
  if (isNumber && !hasLeading) return Number(text.replace(",", "."))
  return value
}


function rowsToObjects(rows) {
  const header  = rows[0] ?? []
  const objects = rows.slice(1).map(row => Object.fromEntries(header.map((key, index) => [key || "colonne " + (index + 1), typeValue(row[index] ?? "")])))
  return objects
}


// Aplatit un objet pour un tableau : sous-objets en colonnes « parent.enfant », listes simples en « a, b, c ».
function flattenRecord(record, prefix) {
  const flat = {}
  for (const [key, value] of Object.entries(record)) {
    const column        = prefix + key
    const isPlainObject = value && typeof value === "object" && !Array.isArray(value)
    const isSimpleList  = Array.isArray(value) && value.every(item => item === null || typeof item !== "object")
    if (isPlainObject) Object.assign(flat, flattenRecord(value, column + "."))
    else if (isSimpleList) flat[column] = value.join(", ")
    else if (Array.isArray(value)) flat[column] = JSON.stringify(value)
    else flat[column] = value ?? ""
  }
  return flat
}


function jsonToSheets(XLSX, data) {
  const isSheetMap = data && !Array.isArray(data) && typeof data === "object" && Object.values(data).every(value => Array.isArray(value))
  const tables     = isSheetMap ? Object.entries(data) : [["Feuille 1", Array.isArray(data) ? data : [data]]]
  const sheets     = tables.map(([name, rows]) => {
    const allArrays = rows.every(row => Array.isArray(row))
    const flatRows  = allArrays ? rows : rows.map(row => (row && typeof row === "object") ? flattenRecord(row, "") : { valeur: row })
    const sheet     = allArrays ? XLSX.utils.aoa_to_sheet(flatRows) : XLSX.utils.json_to_sheet(flatRows)
    return { name: String(name).slice(0, 31), sheet }
  })
  return sheets
}


function sheetsToWorkbook(XLSX, sheets) {
  const workbook = XLSX.utils.book_new()
  sheets.forEach(entry => XLSX.utils.book_append_sheet(workbook, entry.sheet, entry.name))
  const bytes = XLSX.write(workbook, { type: "array", bookType: "xlsx" })
  return new Uint8Array(bytes)
}


// Date d'une cellule : jour seul (« 2026-10-25 ») ou jour et heure (« 2026-10-25 14:30 »), sans décalage horaire.
function formatDate(date) {
  const day     = date.getFullYear() + "-" + padNumber(date.getMonth() + 1, 2) + "-" + padNumber(date.getDate(), 2)
  const hasTime = date.getHours() !== 0 || date.getMinutes() !== 0
  const midday  = date.getHours() === 12 && date.getMinutes() === 0
  if (!hasTime || midday) return day
  return day + " " + padNumber(date.getHours(), 2) + ":" + padNumber(date.getMinutes(), 2)
}


// Date Excel lue depuis son numéro de série (sans passer par Date, qui décale d'une minute avec le fuseau de Paris).
function formatSerialDate(XLSX, serial) {
  const parts   = XLSX.SSF.parse_date_code(serial)
  const day     = parts.y + "-" + padNumber(parts.m, 2) + "-" + padNumber(parts.d, 2)
  const time    = padNumber(parts.H, 2) + ":" + padNumber(parts.M, 2)
  const hasDay  = serial >= 1
  const hasTime = parts.H !== 0 || parts.M !== 0
  if (!hasDay) return time
  return hasTime ? day + " " + time : day
}


function sheetRows(XLSX, sheet) {
  if (!sheet["!ref"]) return []
  const range = XLSX.utils.decode_range(sheet["!ref"])
  const rows  = []
  for (let rowIndex = range.s.r; rowIndex <= range.e.r; rowIndex++) {
    const row = []
    for (let columnIndex = range.s.c; columnIndex <= range.e.c; columnIndex++) {
      const cell    = sheet[XLSX.utils.encode_cell({ r: rowIndex, c: columnIndex })]
      const isDate  = cell && cell.t === "n" && cell.z && XLSX.SSF.is_date(cell.z)
      const value   = !cell || cell.v === undefined ? "" : isDate ? formatSerialDate(XLSX, cell.v) : cell.t === "d" ? formatDate(cell.v) : cell.v
      row.push(value)
    }
    if (row.some(value => value !== "")) rows.push(row)
  }
  return rows
}


// CSV à la française : séparateur « ; », virgule décimale, guillemets si besoin.
function rowsToFrenchCsv(rows) {
  const formatCell = value => {
    const text   = typeof value === "number" ? String(value).replace(".", ",") : String(value ?? "")
    const quoted = /[;"\r\n]/.test(text)
    return quoted ? "\"" + text.replace(/"/g, "\"\"") + "\"" : text
  }
  return rows.map(row => row.map(formatCell).join(CSV_SEPARATOR)).join("\r\n") + "\r\n"
}


function sheetsToCsvOutputs(XLSX, sheets, baseName) {
  const outputs = sheets.map(entry => {
    const csv      = rowsToFrenchCsv(sheetRows(XLSX, entry.sheet))
    const fileName = sheets.length === 1 ? baseName + ".csv" : baseName + " - " + entry.name.replace(/[\\/:*?"<>|#^\[\]]/g, "-") + ".csv"
    return { relativePath: fileName, data: UTF8_BOM + csv }
  })
  return outputs
}


async function convertData(bytes, detection, target, baseName) {
  const XLSX = await loadLibrary("xlsx.min.js", "XLSX")
  if (detection.kind === "csv") {
    const rows = parseCsv(decodeText(bytes))
    if (target.id === "json") return [{ relativePath: baseName + ".json", data: JSON.stringify(rowsToObjects(rows), null, 2) + "\n" }]
    const typedRows = rows.map(row => row.map(value => typeDate(value) ?? typeValue(value)))
    const sheet     = XLSX.utils.aoa_to_sheet(typedRows, { cellDates: true, dateNF: "dd/mm/yyyy" })
    return [{ relativePath: baseName + ".xlsx", data: sheetsToWorkbook(XLSX, [{ name: "Feuille 1", sheet }]) }]
  }
  if (detection.kind === "xlsx") {
    const workbook = XLSX.read(bytes, { type: "array", cellNF: true })
    const sheets   = workbook.SheetNames.map(name => ({ name, sheet: workbook.Sheets[name] }))
    if (target.id === "csv") return sheetsToCsvOutputs(XLSX, sheets, baseName)
    const tables   = sheets.map(entry => [entry.name, rowsToObjects(sheetRows(XLSX, entry.sheet))])
    const data     = tables.length === 1 ? tables[0][1] : Object.fromEntries(tables)
    return [{ relativePath: baseName + ".json", data: JSON.stringify(data, null, 2) + "\n" }]
  }
  const data   = JSON.parse(decodeText(bytes))
  const sheets = jsonToSheets(XLSX, data)
  if (target.id === "csv") return sheetsToCsvOutputs(XLSX, sheets, baseName)
  return [{ relativePath: baseName + ".xlsx", data: sheetsToWorkbook(XLSX, sheets) }]
}


// ---------- Impression en PDF (moteur Chromium d'Obsidian, ordinateur seulement) ----------

function waitForEvent(target, eventName, timeout) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error("Le moteur d'impression ne répond pas.")), timeout)
    target.addEventListener(eventName, () => { clearTimeout(timer); resolve() }, { once: true })
  })
}


async function printHtmlToPdf(html, printOptions) {
  if (!canPrintPdf()) throw new Error("Conversion en PDF disponible sur l'ordinateur seulement.")
  const webview = document.createElement("webview")
  webview.setAttribute("src", PRINT_PAGE_URL)
  webview.setAttribute("style", "position:fixed;left:-20000px;top:0;width:1200px;height:1600px;opacity:0;pointer-events:none")
  const ready = waitForEvent(webview, "dom-ready", PRINT_TIMEOUT_MS)
  document.body.appendChild(webview)
  try {
    await ready
    const writeScript = "document.open();document.write(" + JSON.stringify(html) + ");document.close();true"
    await webview.executeJavaScript(writeScript)
    const waitScript  = "(async()=>{await document.fonts.ready;await Promise.all([...document.images].map(i=>i.complete?0:new Promise(r=>{i.onload=i.onerror=r})));await new Promise(r=>setTimeout(r,150));return true})()"
    await webview.executeJavaScript(waitScript)
    const options     = Object.assign({ printBackground: true, preferCSSPageSize: true, margins: { top: 0, bottom: 0, left: 0, right: 0 } }, printOptions ?? {})
    const data        = await webview.printToPDF(options)
    return new Uint8Array(data)
  } finally {
    webview.remove()
  }
}


function printDocument(title, style, body) {
  return "<!doctype html>\n<html lang=\"fr\">\n<head>\n<meta charset=\"utf-8\">\n<title>" + escapeHtml(title) + "</title>\n<style>" + style + "</style>\n</head>\n<body>\n" + body + "\n</body>\n</html>\n"
}


const NOTE_PRINT_STYLE = `
@page { size: A4; margin: 20mm 18mm 20mm 18mm; }
html { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
body { margin: 0; font-family: "Segoe UI", "Geist", system-ui, sans-serif; font-size: 10.5pt; line-height: 1.55; color: #1d1f23; }
h1 { font-size: 20pt; margin: 0 0 10pt; line-height: 1.2; }
h2 { font-size: 15pt; margin: 18pt 0 6pt; padding-bottom: 3pt; border-bottom: 1px solid #e3e5e8; }
h3 { font-size: 12.5pt; margin: 14pt 0 4pt; }
h4, h5, h6 { font-size: 11pt; margin: 12pt 0 4pt; }
h1, h2, h3, h4 { break-after: avoid; }
p { margin: 0 0 7pt; }
ul, ol { margin: 0 0 8pt; padding-left: 18pt; }
li { margin: 2pt 0; }
a { color: #1f5fbf; text-decoration: none; }
code { font-family: Consolas, "Cascadia Code", monospace; font-size: 9.5pt; background: #f2f3f5; padding: 1pt 3pt; border-radius: 3px; }
pre { background: #f5f6f8; border: 1px solid #e6e8eb; border-radius: 6px; padding: 8pt 10pt; white-space: pre-wrap; break-inside: avoid; }
pre code { background: none; padding: 0; }
blockquote { margin: 8pt 0; padding: 4pt 12pt; border-left: 3px solid #c9ced6; color: #4a5059; }
table { border-collapse: collapse; width: 100%; margin: 6pt 0 10pt; font-size: 9.5pt; break-inside: auto; }
th, td { border: 1px solid #d5d9df; padding: 4pt 7pt; text-align: left; vertical-align: top; }
th { background: #f0f2f5; }
tr { break-inside: avoid; }
img { max-width: 100%; break-inside: avoid; }
hr { border: 0; border-top: 1px solid #d5d9df; margin: 12pt 0; }
input[type=checkbox] { margin-right: 5pt; }
`


const TABLE_PRINT_STYLE = `
@page { size: A4 landscape; margin: 12mm; }
html { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
body { margin: 0; font-family: "Segoe UI", system-ui, sans-serif; font-size: 8.5pt; color: #1d1f23; }
h2 { font-size: 12pt; margin: 0 0 6pt; }
section + section { break-before: page; }
table { border-collapse: collapse; width: 100%; }
td, th { border: 1px solid #d5d9df; padding: 3pt 5pt; text-align: left; vertical-align: top; }
tr:first-child td { background: #f0f2f5; font-weight: 600; }
tr { break-inside: avoid; }
`


function bytesToDataUrl(bytes, mime) {
  let binary = ""
  const CHUNK = 8192
  for (let index = 0; index < bytes.length; index += CHUNK) binary += String.fromCharCode.apply(null, bytes.subarray(index, index + CHUNK))
  return "data:" + mime + ";base64," + btoa(binary)
}


function mimeFromExtension(extension) {
  const MIMES = { png: "image/png", jpg: "image/jpeg", jpeg: "image/jpeg", gif: "image/gif", webp: "image/webp", svg: "image/svg+xml", bmp: "image/bmp", avif: "image/avif" }
  return MIMES[extension] ?? "application/octet-stream"
}


async function readVaultImage(link, sourcePath) {
  const cleanLink = decodeURIComponent(link.split("#")[0].trim())
  const extension = getExtension(cleanLink)
  if (!EMBED_IMAGE_EXTENSIONS.includes(extension)) return null
  const file = app.metadataCache && app.metadataCache.getFirstLinkpathDest ? app.metadataCache.getFirstLinkpathDest(cleanLink, sourcePath ?? "") : null
  if (!file) return null
  const buffer = await app.vault.readBinary(file)
  return { bytes: new Uint8Array(buffer), mime: mimeFromExtension(extension), extension, name: file.name }
}


// Remplace les images intégrées (![[image.png|300]] et ![](image.png)) par des images lisibles hors d'Obsidian.
// mode "data" : URL data intégrée. mode "fichiers" : liste d'images séparées (EPUB).
async function resolveEmbeds(markdown, sourcePath, mode) {
  const images  = []
  const pattern = /!\[\[([^\]|]+)(?:\|(\d+)(?:x\d+)?)?[^\]]*\]\]|!\[([^\]]*)\]\((?!https?:|data:)([^)\s]+)(?:\s+"[^"]*")?\)/g
  const matches = [...markdown.matchAll(pattern)]
  let result    = markdown
  for (const match of matches) {
    const link  = match[1] ?? match[4]
    const width = match[2] ? ` width="${match[2]}"` : ""
    const alt   = escapeHtml(match[3] ?? link)
    const image = await readVaultImage(link, sourcePath)
    if (!image) continue
    let source = ""
    if (mode === "fichiers") {
      const fileName = "image-" + padNumber(images.length + 1, 2) + "." + image.extension.replace("jpeg", "jpg")
      images.push({ fileName, bytes: image.bytes, mime: image.mime })
      source = "images/" + fileName
    } else {
      source = bytesToDataUrl(image.bytes, image.mime)
    }
    result = result.replace(match[0], `<img src="${source}" alt="${alt}"${width}>`)
  }
  return { markdown: result, images }
}


async function noteToPrintableHtml(bytes, baseName, sourcePath) {
  const marked   = await loadLibrary("marked.min.js", "marked")
  const text     = decodeText(bytes).replace(/^---\r?\n[\s\S]*?\r?\n---\r?\n/, "")
  const resolved = await resolveEmbeds(text, sourcePath, "data")
  const markdown = cleanObsidianMarkdown(resolved.markdown)
  const body     = marked.parse(markdown, { gfm: true })
  return printDocument(baseName, NOTE_PRINT_STYLE, body)
}


async function noteToPdf(bytes, baseName, sourcePath) {
  const page     = await noteToPrintableHtml(bytes, baseName, sourcePath)
  const pdfBytes = await printHtmlToPdf(page)
  return [{ relativePath: baseName + ".pdf", data: pdfBytes }]
}


async function htmlToPdf(bytes, baseName) {
  const page     = decodeText(bytes)
  const pdfBytes = await printHtmlToPdf(page, { preferCSSPageSize: true, pageSize: "A4", margins: { top: 0.6, bottom: 0.6, left: 0.6, right: 0.6 } })
  return [{ relativePath: baseName + ".pdf", data: pdfBytes }]
}


async function htmlToNote(bytes, baseName) {
  const TurndownService   = await loadLibrary("turndown.js", "TurndownService")
  const turndownPluginGfm = await loadLibrary("turndown-gfm.js", "turndownPluginGfm")
  const parser    = new DOMParser()
  const document  = parser.parseFromString(decodeText(bytes), "text/html")
  document.querySelectorAll("script, style, noscript, iframe").forEach(element => element.remove())
  const turndown  = new TurndownService({ headingStyle: "atx", codeBlockStyle: "fenced", bulletListMarker: "-", emDelimiter: "*" })
  turndown.use(turndownPluginGfm.gfm)
  const markdown  = turndown.turndown(document.body.innerHTML).trim() + "\n"
  return [{ relativePath: baseName + ".md", data: markdown }]
}


async function tableToPdf(bytes, detection, baseName) {
  const XLSX     = await loadLibrary("xlsx.min.js", "XLSX")
  const workbook = detection.kind === "csv" ? XLSX.utils.book_new() : XLSX.read(bytes, { type: "array" })
  if (detection.kind === "csv") {
    const rows  = parseCsv(decodeText(bytes))
    XLSX.utils.book_append_sheet(workbook, XLSX.utils.aoa_to_sheet(rows), "Feuille 1")
  }
  const sections = workbook.SheetNames.map(name => {
    const table = XLSX.utils.sheet_to_html(workbook.Sheets[name], { header: "", footer: "" })
    const title = workbook.SheetNames.length > 1 ? "<h2>" + escapeHtml(name) + "</h2>" : ""
    return "<section>" + title + table + "</section>"
  })
  const page     = printDocument(baseName, TABLE_PRINT_STYLE, sections.join("\n"))
  const pdfBytes = await printHtmlToPdf(page)
  return [{ relativePath: baseName + ".pdf", data: pdfBytes }]
}


// Word vers PDF.
// 1. docx-preview met en forme le contenu (styles, titres, listes, tableaux, images, polices, couleurs).
// 2. Le contenu s'écoule de page en page avec les vraies marges du document (règles @page nommées par section).
// 3. En-têtes et pieds de page sont refaits depuis le XML du document et imprimés sur chaque page par Chromium,
//    avec les champs « numéro de page » et « nombre de pages ».
const TWIPS_PER_POINT = 20
const EMU_PER_PIXEL   = 9525

function xmlChildren(element, name) {
  return [...element.childNodes].filter(node => node.nodeType === 1 && node.nodeName === name)
}


function xmlFirst(element, name) {
  return element ? element.getElementsByTagName(name)[0] ?? null : null
}


function twipsAttribute(element, name, fallback) {
  const value = element ? element.getAttribute(name) : null
  return value === null || value === undefined || value === "" ? fallback : Number(value) / TWIPS_PER_POINT
}


async function readZipText(zip, path) {
  const entry = zip.file(path)
  return entry ? entry.async("string") : null
}


function parseRelations(xmlText) {
  const relations = new Map()
  if (!xmlText) return relations
  const document = new DOMParser().parseFromString(xmlText, "application/xml")
  for (const relation of document.getElementsByTagName("Relationship")) relations.set(relation.getAttribute("Id"), relation.getAttribute("Target"))
  return relations
}


function runStyle(run) {
  const properties = xmlFirst(run, "w:rPr")
  if (!properties) return ""
  const styles = []
  const bold   = xmlFirst(properties, "w:b")
  const italic = xmlFirst(properties, "w:i")
  const color  = xmlFirst(properties, "w:color")
  const size   = xmlFirst(properties, "w:sz")
  if (bold && bold.getAttribute("w:val") !== "0" && bold.getAttribute("w:val") !== "false") styles.push("font-weight:700")
  if (italic && italic.getAttribute("w:val") !== "0" && italic.getAttribute("w:val") !== "false") styles.push("font-style:italic")
  if (color && /^[0-9A-Fa-f]{6}$/.test(color.getAttribute("w:val") ?? "")) styles.push("color:#" + color.getAttribute("w:val"))
  if (size && size.getAttribute("w:val")) styles.push("font-size:" + Number(size.getAttribute("w:val")) / 2 + "pt")
  return styles.join(";")
}


function fieldSpan(instruction) {
  const code = String(instruction ?? "").trim().split(/\s+/)[0].toUpperCase()
  if (code === "PAGE") return "<span class=\"pageNumber\"></span>"
  if (code === "NUMPAGES" || code === "SECTIONPAGES") return "<span class=\"totalPages\"></span>"
  return null
}


async function drawingHtml(drawing, relations, zip, partFolder) {
  const blip   = xmlFirst(drawing, "a:blip")
  const extent = xmlFirst(drawing, "wp:extent")
  if (!blip) return ""
  const target = relations.get(blip.getAttribute("r:embed"))
  if (!target) return ""
  const path   = target.startsWith("/") ? target.slice(1) : partFolder + target
  const entry  = zip.file(path.replace(/[^/]+\/\.\.\//g, ""))
  if (!entry) return ""
  const bytes  = await entry.async("uint8array")
  const width  = extent ? Math.round(Number(extent.getAttribute("cx")) / EMU_PER_PIXEL) : 0
  const height = extent ? Math.round(Number(extent.getAttribute("cy")) / EMU_PER_PIXEL) : 0
  const size   = width && height ? ` style="width:${width * 0.75}pt;height:${height * 0.75}pt;vertical-align:middle"` : ""
  return `<img src="${bytesToDataUrl(bytes, mimeFromExtension(getExtension(path)))}"${size}>`
}


async function paragraphSegments(paragraph, relations, zip, partFolder) {
  const segments = [""]
  const field    = { active: false, instruction: "", showResult: true }
  const append   = html => { segments[segments.length - 1] += html }
  const visit    = async node => {
    for (const child of node.childNodes) {
      if (child.nodeType !== 1) continue
      const name = child.nodeName
      if (name === "w:fldSimple") {
        const span = fieldSpan(child.getAttribute("w:instr"))
        if (span) append(span)
        else await visit(child)
        continue
      }
      if (name === "w:hyperlink" || name === "w:smartTag" || name === "w:sdt" || name === "w:sdtContent" || name === "w:ins") { await visit(child); continue }
      if (name !== "w:r") continue
      const style = runStyle(child)
      for (const part of child.childNodes) {
        if (part.nodeType !== 1) continue
        const partName = part.nodeName
        if (partName === "w:fldChar") {
          const type = part.getAttribute("w:fldCharType")
          if (type === "begin") { field.active = true; field.instruction = ""; field.showResult = true }
          if (type === "separate") { const span = fieldSpan(field.instruction); if (span) { append(span); field.showResult = false } }
          if (type === "end") { field.active = false; field.showResult = true }
          continue
        }
        if (partName === "w:instrText") { field.instruction += part.textContent; continue }
        if (field.active && !field.showResult) continue
        if (partName === "w:t") append(style ? `<span style="${style}">${escapeHtml(part.textContent)}</span>` : escapeHtml(part.textContent))
        if (partName === "w:tab") segments.push("")
        if (partName === "w:br") append("<br>")
        if (partName === "w:drawing") append(await drawingHtml(part, relations, zip, partFolder))
      }
    }
  }
  await visit(paragraph)
  return segments
}


async function headerFooterHtml(zip, target) {
  if (!target) return ""
  const path      = "word/" + target.replace(/^\/?word\//, "")
  const xmlText   = await readZipText(zip, path)
  if (!xmlText) return ""
  const fileName  = path.split("/").pop()
  const partFolder = path.slice(0, path.length - fileName.length)
  const relations = parseRelations(await readZipText(zip, partFolder + "_rels/" + fileName + ".rels"))
  const document  = new DOMParser().parseFromString(xmlText, "application/xml")
  const blocks    = []
  for (const paragraph of document.getElementsByTagName("w:p")) {
    const alignment = xmlFirst(xmlFirst(paragraph, "w:pPr"), "w:jc")?.getAttribute("w:val") ?? "left"
    const align     = { center: "center", right: "right", end: "right", both: "justify" }[alignment] ?? "left"
    const segments  = await paragraphSegments(paragraph, relations, zip, partFolder)
    const visible   = segments.filter(segment => segment.replace(/<[^>]+>/g, "").trim() !== "" || segment.includes("<img") || segment.includes("class=\""))
    if (visible.length === 0) continue
    if (segments.length >= 2) {
      const columns = segments.map((segment, index) => {
        const textAlign = segments.length === 2 ? (index === 0 ? "left" : "right") : (index === 0 ? "left" : index === segments.length - 1 ? "right" : "center")
        return `<div style="flex:1;text-align:${textAlign}">${segment}</div>`
      }).join("")
      blocks.push(`<div style="display:flex;gap:12pt">${columns}</div>`)
      continue
    }
    blocks.push(`<div style="text-align:${align}">${segments[0]}</div>`)
  }
  return blocks.join("")
}


async function readWordLayout(bytes) {
  const JSZip     = await loadLibrary("jszip.min.js", "JSZip")
  const zip       = await JSZip.loadAsync(bytes)
  const xmlText   = await readZipText(zip, "word/document.xml")
  const relations = parseRelations(await readZipText(zip, "word/_rels/document.xml.rels"))
  const document  = new DOMParser().parseFromString(xmlText ?? "<x/>", "application/xml")
  const body      = xmlFirst(document, "w:body")
  const sectPr    = body ? xmlChildren(body, "w:sectPr")[0] ?? null : null
  const margins   = xmlFirst(sectPr, "w:pgMar")
  const layout    = {
    top:    twipsAttribute(margins, "w:top", 72),
    bottom: twipsAttribute(margins, "w:bottom", 72),
    left:   twipsAttribute(margins, "w:left", 72),
    right:  twipsAttribute(margins, "w:right", 72),
    header: twipsAttribute(margins, "w:header", 36),
    footer: twipsAttribute(margins, "w:footer", 36)
  }
  const reference = (name, type) => {
    const references = sectPr ? xmlChildren(sectPr, name) : []
    const found      = references.find(item => item.getAttribute("w:type") === type) ?? references.find(item => item.getAttribute("w:type") === "default")
    return found ? relations.get(found.getAttribute("r:id")) : null
  }
  layout.headerHtml = await headerFooterHtml(zip, reference("w:headerReference", "default"))
  layout.footerHtml = await headerFooterHtml(zip, reference("w:footerReference", "default"))
  return layout
}


function headerFooterTemplate(content, layout, isFooter) {
  if (!content) return "<span></span>"
  const LINE_HEIGHT = 12
  const top    = isFooter ? Math.max(0, layout.bottom - layout.footer - LINE_HEIGHT * 1.6) : layout.header
  const wrapper = `width:100%;box-sizing:border-box;margin:0;padding:${top}pt ${layout.right}pt 0 ${layout.left}pt;font-family:Calibri,'Segoe UI',Arial,sans-serif;font-size:9pt;line-height:1.25;color:#000;-webkit-print-color-adjust:exact`
  return `<div style="${wrapper}">${content}</div>`
}


async function wordToPdf(bytes, baseName, onProgress) {
  await loadLibrary("jszip.min.js", "JSZip")
  const docxPreview = await loadLibrary("docx-preview.min.js", "docx")
  const holder      = document.createElement("div")
  const styleHolder = document.createElement("div")
  holder.setAttribute("style", "position:fixed;left:-20000px;top:0;width:1200px")
  document.body.append(holder, styleHolder)
  try {
    onProgress(0.15, "Lecture de la mise en page…")
    const layout  = await readWordLayout(bytes)
    onProgress(0.3, "Mise en forme du document…")
    const options = { className: "docx", inWrapper: false, ignoreWidth: false, ignoreHeight: false, ignoreFonts: false, breakPages: true, ignoreLastRenderedPageBreak: true, experimental: true, renderHeaders: false, renderFooters: false, renderFootnotes: true, renderEndnotes: true, useBase64URL: true }
    await docxPreview.renderAsync(toBlob(bytes, "application/vnd.openxmlformats-officedocument.wordprocessingml.document"), holder, styleHolder, options)
    const sections = [...holder.querySelectorAll("section.docx")]
    if (sections.length === 0) throw new Error("Document Word vide ou illisible.")
    const pageRules = sections.map((section, index) => {
      const width   = section.style.width || "595.3pt"
      const height  = section.style.minHeight || "841.9pt"
      const margins = [section.style.paddingTop, section.style.paddingRight, section.style.paddingBottom, section.style.paddingLeft].map(value => value || "72pt").join(" ")
      section.setAttribute("style", "page: cv-page-" + index)
      return "@page cv-page-" + index + " { size: " + width + " " + height + "; margin: " + margins + "; }"
    })
    const style = pageRules.join("\n") + `
html, body { margin: 0; padding: 0; background: #ffffff; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
section.docx { margin: 0 !important; padding: 0 !important; box-shadow: none !important; background: transparent !important; width: auto !important; min-height: 0 !important; break-after: page; }
section.docx:last-of-type { break-after: auto; }
section.docx table { break-inside: auto; }
section.docx tr, section.docx img { break-inside: avoid; }`
    const page = "<!doctype html>\n<html lang=\"fr\"><head><meta charset=\"utf-8\"><title>" + escapeHtml(baseName) + "</title>" + styleHolder.innerHTML + "<style>" + style + "</style></head><body>" + holder.innerHTML + "</body></html>"
    onProgress(0.6, "Impression en PDF…")
    const hasHeaderFooter = Boolean(layout.headerHtml || layout.footerHtml)
    const pdfBytes = await printHtmlToPdf(page, {
      displayHeaderFooter: hasHeaderFooter,
      headerTemplate:      headerFooterTemplate(layout.headerHtml, layout, false),
      footerTemplate:      headerFooterTemplate(layout.footerHtml, layout, true)
    })
    return [{ relativePath: baseName + ".pdf", data: pdfBytes }]
  } finally {
    holder.remove()
    styleHolder.remove()
  }
}


// ---------- PDF vers Word (mise en page simplifiée) ----------

function multiplyMatrix(first, second) {
  return [
    first[0] * second[0] + first[2] * second[1],
    first[1] * second[0] + first[3] * second[1],
    first[0] * second[2] + first[2] * second[3],
    first[1] * second[2] + first[3] * second[3],
    first[0] * second[4] + first[2] * second[5] + first[4],
    first[1] * second[4] + first[3] * second[5] + first[5]
  ]
}


function getPdfObject(store, name) {
  return new Promise(resolve => {
    const timer = setTimeout(() => resolve(null), 3000)
    try {
      store.get(name, value => { clearTimeout(timer); resolve(value) })
    } catch (error) {
      clearTimeout(timer)
      resolve(null)
    }
  })
}


async function pdfImageToPng(image) {
  if (!image) return null
  const canvas  = window.document.createElement("canvas")
  canvas.width  = image.width
  canvas.height = image.height
  const context = canvas.getContext("2d")
  if (image.bitmap) {
    context.drawImage(image.bitmap, 0, 0)
  } else if (image.data) {
    const imageData = context.createImageData(image.width, image.height)
    const pixels    = image.data
    const target    = imageData.data
    const KIND_RGB  = 2
    const KIND_RGBA = 3
    if (image.kind === KIND_RGBA) target.set(pixels.subarray(0, target.length))
    else if (image.kind === KIND_RGB) {
      for (let source = 0, destination = 0; destination < target.length; source += 3, destination += 4) {
        target[destination] = pixels[source]; target[destination + 1] = pixels[source + 1]; target[destination + 2] = pixels[source + 2]; target[destination + 3] = 255
      }
    } else return null
    context.putImageData(imageData, 0, 0)
  } else return null
  return canvasToBytes(canvas, "image/png")
}


async function collectPdfImages(page, pdfjsLib) {
  const operators = await page.getOperatorList()
  const OPS       = pdfjsLib.OPS
  const images    = []
  const stack     = []
  let matrix      = [1, 0, 0, 1, 0, 0]
  for (let index = 0; index < operators.fnArray.length; index++) {
    const operation = operators.fnArray[index]
    const args      = operators.argsArray[index]
    if (operation === OPS.save) { stack.push(matrix); continue }
    if (operation === OPS.restore) { matrix = stack.pop() ?? [1, 0, 0, 1, 0, 0]; continue }
    if (operation === OPS.transform) { matrix = multiplyMatrix(matrix, args); continue }
    const isImage = operation === OPS.paintImageXObject || operation === OPS.paintInlineImageXObject
    if (!isImage) continue
    const width  = Math.hypot(matrix[0], matrix[1])
    const height = Math.hypot(matrix[2], matrix[3])
    if (width < MIN_IMAGE_POINTS || height < MIN_IMAGE_POINTS) continue
    const name   = args[0]
    const store  = typeof name === "string" && name.startsWith("g_") ? page.commonObjs : page.objs
    const object = typeof name === "string" ? await getPdfObject(store, name) : name
    const png    = await pdfImageToPng(object)
    if (png) images.push({ y: matrix[5] + height, width, height, png })
  }
  return images
}


function fontStyle(page, fontName) {
  try {
    const font = page.commonObjs.has(fontName) ? page.commonObjs.get(fontName) : null
    const name = String(font?.name ?? fontName)
    return { bold: /bold|black|heavy|semibold|demi/i.test(name), italics: /italic|oblique/i.test(name) }
  } catch (error) {
    return { bold: false, italics: false }
  }
}


function buildLines(page, items) {
  const pieces = items.filter(item => typeof item.str === "string" && item.str.trim() !== "").map(item => {
    const size  = Math.round(Math.hypot(item.transform[2], item.transform[3]) * 2) / 2
    const style = fontStyle(page, item.fontName)
    return { text: item.str, x: item.transform[4], y: item.transform[5], width: item.width, size, bold: style.bold, italics: style.italics }
  })
  pieces.sort((first, second) => (second.y - first.y) || (first.x - second.x))
  const lines = []
  for (const piece of pieces) {
    const line = lines.find(candidate => Math.abs(candidate.y - piece.y) < Math.max(candidate.size, piece.size) * 0.45)
    if (line) { line.pieces.push(piece); line.size = Math.max(line.size, piece.size); continue }
    lines.push({ y: piece.y, size: piece.size, pieces: [piece] })
  }
  for (const line of lines) {
    line.pieces.sort((first, second) => first.x - second.x)
    const cells = [[]]
    let lastEnd = null
    for (const piece of line.pieces) {
      const gap        = lastEnd === null ? 0 : piece.x - lastEnd
      const newCell    = lastEnd !== null && gap > piece.size * 1.6
      if (newCell) cells.push([])
      const runs       = cells.at(-1)
      const previous   = runs.at(-1)
      const needsSpace = !newCell && lastEnd !== null && gap > piece.size * 0.2 && !/\s$/.test(previous?.text ?? "") && !/^\s/.test(piece.text)
      const text       = (needsSpace ? " " : "") + piece.text
      if (previous && previous.bold === piece.bold && previous.italics === piece.italics) previous.text += text
      else runs.push({ text, bold: piece.bold, italics: piece.italics })
      lastEnd = piece.x + piece.width
    }
    line.cells = cells.filter(runs => runs.some(run => run.text.trim() !== ""))
    line.runs  = line.cells.flatMap((runs, index) => index === 0 ? runs : [{ text: "\t", bold: false, italics: false }, ...runs])
    line.text  = line.runs.map(run => run.text).join("")
    line.x     = line.pieces[0].x
    line.end   = lastEnd
  }
  return lines.filter(line => line.text.trim() !== "")
}


// Retire les lignes répétées en haut ou en bas de plusieurs pages (en-têtes, pieds de page, numéros de page).
function removeRepeatedMargins(pages) {
  if (pages.length < 2) return
  const key    = line => Math.round(line.y) + "|" + line.text.replace(/\d+/g, "#").trim()
  const counts = new Map()
  for (const page of pages) {
    const keys = new Set(page.lines.filter(line => line.y > page.height * 0.88 || line.y < page.height * 0.12).map(key))
    for (const value of keys) counts.set(value, (counts.get(value) ?? 0) + 1)
  }
  for (const page of pages) {
    page.lines = page.lines.filter(line => {
      const inMargin = line.y > page.height * 0.88 || line.y < page.height * 0.12
      return !(inMargin && (counts.get(key(line)) ?? 0) >= 2)
    })
  }
}


function bodyFontSize(allLines) {
  const weights = new Map()
  for (const line of allLines) weights.set(line.size, (weights.get(line.size) ?? 0) + line.text.length)
  const sorted = [...weights.entries()].sort((first, second) => second[1] - first[1])
  return sorted.length ? sorted[0][0] : 11
}


function groupBlocks(blocks, bodySize, rightEdge) {
  const BULLET = /^\s*[•▪●◦‣·\-–]\s+/
  const groups = []
  for (const block of blocks) {
    if (block.type === "image") { groups.push(block); continue }
    const line     = block
    const previous = groups.at(-1)
    const isTable  = line.cells.length >= 2
    if (isTable) {
      const sameTable = previous && previous.type === "tableau" && previous.columnCount === line.cells.length && (previous.lastY - line.y) <= line.size * 3
      if (sameTable) { previous.rows.push(line.cells); previous.lastY = line.y; continue }
      groups.push({ type: "tableau", columnCount: line.cells.length, rows: [line.cells], lastY: line.y })
      continue
    }
    const isBullet  = BULLET.test(line.text)
    const isHeading = line.size >= bodySize * 1.2
    const canJoin   = previous && previous.type === "texte"
      && Math.abs(previous.size - line.size) < 0.6
      && (previous.lastY - line.y) <= line.size * 1.75
      && !isBullet
      && previous.isHeading === isHeading
      && previous.lastEnd >= rightEdge - line.size * 6
      && (!previous.isBullet || line.x > previous.firstX + 1)
    if (canJoin) {
      const lastRun  = previous.runs.at(-1)
      const hyphened = /[a-zà-ÿ]-$/i.test(lastRun.text) && /^[a-zà-ÿ]/.test(line.text)
      if (hyphened) lastRun.text = lastRun.text.slice(0, -1)
      else lastRun.text += " "
      previous.runs.push(...line.runs.map(run => Object.assign({}, run)))
      previous.lastY   = line.y
      previous.lastEnd = line.end
      continue
    }
    const runs = line.runs.map(run => Object.assign({}, run))
    if (isBullet) runs[0].text = runs[0].text.replace(BULLET, "")
    groups.push({ type: "texte", size: line.size, runs, lastY: line.y, lastEnd: line.end, firstX: line.x, isBullet, isHeading })
  }
  return groups
}


function docxTable(docx, group) {
  const rows = group.rows.map(cells => new docx.TableRow({
    children: cells.map(runs => new docx.TableCell({ children: [new docx.Paragraph({ children: runs.map(run => new docx.TextRun({ text: run.text.trim(), bold: run.bold, italics: run.italics })) })] }))
  }))
  return new docx.Table({ width: { size: 100, type: docx.WidthType.PERCENTAGE }, rows })
}


async function pdfToDocx(bytes, baseName, onProgress) {
  const pdfjsLib  = await loadPdfJs()
  const docx      = await loadLibrary("docx.js", "docx")
  const pdf       = await openPdfForReading(bytes)
  const pageCount = pdf.numPages
  const pages     = []
  for (let pageNumber = 1; pageNumber <= pageCount; pageNumber++) {
    const page     = await pdf.getPage(pageNumber)
    const images   = await collectPdfImages(page, pdfjsLib)
    const content  = await page.getTextContent()
    const lines    = buildLines(page, content.items)
    const viewport = page.getViewport({ scale: 1 })
    pages.push({ lines, images, width: viewport.width, height: viewport.height })
    page.cleanup()
    onProgress(pageNumber / pageCount * 0.8, "Lecture de la page " + pageNumber + " sur " + pageCount)
  }
  await pdf.destroy()
  removeRepeatedMargins(pages)
  const allLines     = pages.flatMap(page => page.lines)
  const bodySize     = bodyFontSize(allLines)
  const headingSizes = [...new Set(allLines.map(line => line.size).filter(size => size >= bodySize * 1.2))].sort((first, second) => second - first)
  const firstPage    = pages[0] ?? { width: A4_WIDTH, height: A4_HEIGHT }
  const MARGIN_TWIPS = 1134
  const contentWidth = (firstPage.width * 20 - MARGIN_TWIPS * 2) / 15
  const children     = []
  pages.forEach((page, pageIndex) => {
    const rightEdge = Math.max(...page.lines.map(line => line.end), 0)
    const blocks    = [...page.lines.map(line => Object.assign({ type: "ligne" }, line)), ...page.images.map(image => Object.assign({ type: "image" }, image))].sort((first, second) => second.y - first.y)
    const groups    = groupBlocks(blocks, bodySize, rightEdge)
    if (pageIndex > 0 && groups.length) children.push(new docx.Paragraph({ children: [new docx.PageBreak()] }))
    for (const group of groups) {
      if (group.type === "image") {
        const ratio  = Math.min(1, contentWidth / (group.width * 96 / 72))
        const width  = Math.round(group.width * 96 / 72 * ratio)
        const height = Math.round(group.height * 96 / 72 * ratio)
        children.push(new docx.Paragraph({ children: [new docx.ImageRun({ data: group.png, transformation: { width, height } })] }))
        continue
      }
      if (group.type === "tableau") {
        children.push(docxTable(docx, group))
        children.push(new docx.Paragraph({ children: [] }))
        continue
      }
      const runs    = group.runs.map(run => new docx.TextRun({ text: run.text, bold: run.bold, italics: run.italics, size: group.isHeading ? undefined : Math.round(group.size * 2) }))
      const level   = headingSizes.indexOf(group.size)
      const heading = group.isHeading && level >= 0 ? docx.HeadingLevel["HEADING_" + Math.min(level + 1, 3)] : undefined
      const bullet  = group.isBullet ? { bullet: { level: 0 } } : {}
      children.push(new docx.Paragraph(Object.assign({ heading, children: runs, spacing: { after: 120 } }, bullet)))
    }
  })
  onProgress(0.9, "Création du document Word…")
  const document = new docx.Document({
    creator: "Convertisseur",
    title: baseName,
    styles: { default: { document: { run: { font: DOCUMENT_FONT, size: Math.round(bodySize * 2) } } } },
    sections: [{ properties: { page: { size: { width: Math.round(firstPage.width * 20), height: Math.round(firstPage.height * 20) }, margin: { top: MARGIN_TWIPS, bottom: MARGIN_TWIPS, left: MARGIN_TWIPS, right: MARGIN_TWIPS } } }, children }]
  })
  const blob      = await docx.Packer.toBlob(document)
  const docxBytes = await blobToBytes(blob)
  return [{ relativePath: baseName + ".docx", data: docxBytes }]
}


// ---------- Compression de PDF ----------

async function compressPdf(bytes, baseName, onProgress) {
  const PDFLib    = await loadLibrary("pdf-lib.min.js", "PDFLib")
  const source    = await openPdfForReading(bytes)
  const result    = await PDFLib.PDFDocument.create()
  const scale     = COMPRESS_DPI / 72
  const pageCount = source.numPages
  for (let pageNumber = 1; pageNumber <= pageCount; pageNumber++) {
    const page     = await source.getPage(pageNumber)
    const natural  = page.getViewport({ scale: 1 })
    const viewport = page.getViewport({ scale })
    const canvas   = window.document.createElement("canvas")
    canvas.width   = Math.round(viewport.width)
    canvas.height  = Math.round(viewport.height)
    const context  = canvas.getContext("2d")
    context.fillStyle = "#ffffff"
    context.fillRect(0, 0, canvas.width, canvas.height)
    await page.render({ canvasContext: context, viewport }).promise
    const jpgBytes = await canvasToBytes(canvas, "image/jpeg", COMPRESS_QUALITY)
    const image    = await result.embedJpg(jpgBytes)
    const newPage  = result.addPage([natural.width, natural.height])
    newPage.drawImage(image, { x: 0, y: 0, width: natural.width, height: natural.height })
    page.cleanup()
    onProgress(pageNumber / pageCount, "Page " + pageNumber + " sur " + pageCount)
  }
  await source.destroy()
  const pdfBytes = await result.save()
  if (pdfBytes.length >= bytes.length) throw new Error("Ce PDF est déjà plus léger que sa version compressée.")
  return [{ relativePath: baseName + ".pdf", data: pdfBytes }]
}


// ---------- Note vers EPUB ----------

function toXhtml(html) {
  const document = window.document.implementation.createHTMLDocument("")
  document.body.innerHTML = html
  const serializer = new XMLSerializer()
  return [...document.body.childNodes].map(node => serializer.serializeToString(node)).join("\n")
}


async function noteToEpub(bytes, baseName, sourcePath) {
  const marked   = await loadLibrary("marked.min.js", "marked")
  const JSZip    = await loadLibrary("jszip.min.js", "JSZip")
  const text     = decodeText(bytes).replace(/^---\r?\n[\s\S]*?\r?\n---\r?\n/, "")
  const resolved = await resolveEmbeds(text, sourcePath, "fichiers")
  const markdown = cleanObsidianMarkdown(resolved.markdown)
  const tokens   = marked.lexer(markdown, { gfm: true })
  const headings = tokens.filter(token => token.type === "heading" && token.depth <= 2)
  let headingIndex = 0
  const renderer = new marked.Renderer()
  renderer.heading = (textValue, level) => {
    const content = typeof textValue === "object" ? marked.parseInline(textValue.text) : textValue
    const depth   = typeof textValue === "object" ? textValue.depth : level
    const id      = depth <= 2 ? ` id="titre-${++headingIndex}"` : ""
    return `<h${depth}${id}>${content}</h${depth}>\n`
  }
  const body       = toXhtml(marked.parse(markdown, { gfm: true, renderer }))
  const identifier = "urn:uuid:" + (crypto.randomUUID ? crypto.randomUUID() : String(Date.now()))
  const modified   = new Date().toISOString().replace(/\.\d+Z$/, "Z")
  const title      = escapeHtml(baseName)
  const navItems   = headings.map((heading, index) => `<li><a href="texte.xhtml#titre-${index + 1}">${escapeHtml(heading.text)}</a></li>`).join("\n")
  const imageItems = resolved.images.map((image, index) => `<item id="image${index + 1}" href="images/${image.fileName}" media-type="${image.mime}"/>`).join("\n    ")
  const zip        = new JSZip()
  zip.file("mimetype", "application/epub+zip", { compression: "STORE" })
  zip.file("META-INF/container.xml", `<?xml version="1.0" encoding="UTF-8"?>\n<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container"><rootfiles><rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/></rootfiles></container>`)
  zip.file("OEBPS/content.opf", `<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="identifiant" xml:lang="fr">
  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/">
    <dc:identifier id="identifiant">${identifier}</dc:identifier>
    <dc:title>${title}</dc:title>
    <dc:language>fr</dc:language>
    <meta property="dcterms:modified">${modified}</meta>
  </metadata>
  <manifest>
    <item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>
    <item id="texte" href="texte.xhtml" media-type="application/xhtml+xml"/>
    <item id="style" href="style.css" media-type="text/css"/>
    ${imageItems}
  </manifest>
  <spine><itemref idref="texte"/></spine>
</package>`)
  zip.file("OEBPS/nav.xhtml", `<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE html>\n<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" xml:lang="fr"><head><title>${title}</title></head><body><nav epub:type="toc"><h1>Sommaire</h1><ol>${navItems || `<li><a href="texte.xhtml">${title}</a></li>`}</ol></nav></body></html>`)
  zip.file("OEBPS/style.css", "body{font-family:serif;line-height:1.5}h1,h2,h3{font-family:sans-serif}img{max-width:100%}pre{white-space:pre-wrap}table{border-collapse:collapse}td,th{border:1px solid #999;padding:2px 6px}")
  zip.file("OEBPS/texte.xhtml", `<?xml version="1.0" encoding="UTF-8"?>\n<!DOCTYPE html>\n<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="fr"><head><title>${title}</title><link rel="stylesheet" type="text/css" href="style.css"/></head><body>\n${body}\n</body></html>`)
  for (const image of resolved.images) zip.file("OEBPS/images/" + image.fileName, image.bytes)
  const epubBytes = await zip.generateAsync({ type: "uint8array", mimeType: "application/epub+zip" })
  return [{ relativePath: baseName + ".epub", data: epubBytes }]
}


// ---------- Point d'entrée ----------

async function convert(request) {
  const bytes        = request.bytes
  const detection    = request.detection
  const target       = getTargets(detection).find(candidate => candidate.id === request.targetId)
  const baseName     = request.baseName
  const onProgress   = request.onProgress ?? (() => {})
  if (!target) throw new Error("Format de sortie inconnu.")
  if (detection.kind === "image" || detection.kind === "svg") return convertImage(bytes, detection, target, baseName)
  if (detection.kind === "pdf") {
    if (target.id === "texte")      return pdfToText(bytes, baseName, onProgress)
    if (target.id === "docx")       return pdfToDocx(bytes, baseName, onProgress)
    if (target.id === "compresser") return compressPdf(bytes, baseName, onProgress)
    if (target.id === "extraire") return extractPages(bytes, request.pages, baseName)
    if (target.id === "tourner")  return rotatePdf(bytes, baseName)
    return pdfToImages(bytes, target, baseName, onProgress)
  }
  if (detection.kind === "word") {
    if (target.id === "pdf")  return wordToPdf(bytes, baseName, onProgress)
    if (target.id === "note") return wordToNote(bytes, baseName, request.outputFolder)
    return wordToHtml(bytes, baseName)
  }
  if (detection.kind === "note") {
    if (target.id === "pdf")  return noteToPdf(bytes, baseName, request.sourcePath)
    if (target.id === "docx") return noteToDocx(bytes, baseName)
    if (target.id === "epub") return noteToEpub(bytes, baseName, request.sourcePath)
    return noteToHtml(bytes, baseName, request.sourcePath)
  }
  if (detection.kind === "html") return target.id === "pdf" ? htmlToPdf(bytes, baseName) : htmlToNote(bytes, baseName)
  if (target.id === "pdf") return tableToPdf(bytes, detection, baseName)
  return convertData(bytes, detection, target, baseName)
}


const LIBRARY_PATH = loadLibrary.folder

return { detectKind, describe, getTargets, getDefaultTarget, convert, assembleImages, mergePdfs, getExtension }
