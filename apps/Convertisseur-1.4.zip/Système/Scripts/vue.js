// Vue de l'application « Convertisseur » (note d'entrée), maquette C « Liste compacte ».
// Appel : await dv.view("Convertisseur/Système/Scripts/vue")
// Lit Inbox/, Système/apparence.json, Système/réglages.json, Système/Bibliothèques/ (à la demande).
// Écrit dans Convertis/, Originaux/, Fonds/, apparence.json et réglages.json. Met les originaux de l'Inbox à la corbeille d'Obsidian si « Conserver les originaux » est désactivé.
// Styles limités à la classe de note « cv » et au conteneur « .cv-app ».

const APP_FOLDER        = "Convertisseur"
const SYSTEM_FOLDER     = APP_FOLDER + "/Système"
const SCRIPT_FOLDER     = SYSTEM_FOLDER + "/Scripts"
const LIBRARY_FOLDER    = SYSTEM_FOLDER + "/Bibliothèques"
const INBOX_FOLDER      = APP_FOLDER + "/Inbox"
const OUTPUT_FOLDER     = APP_FOLDER + "/Convertis"
const ORIGINALS_FOLDER  = APP_FOLDER + "/Originaux"
const BACKGROUND_FOLDER = APP_FOLDER + "/Fonds"
const APPEARANCE_PATH   = SYSTEM_FOLDER + "/apparence.json"
const SETTINGS_PATH     = SYSTEM_FOLDER + "/réglages.json"
const ENGINE_PATH       = SCRIPT_FOLDER + "/conversions.js"

const DEFAULT_APPEARANCE = {
  fond:                "Fonds/Forêt dans la brume.jpg",
  voile:               "auto",
  assombrir:           0,
  flou:                20,
  teinte:              0.6,
  reduireTransparence: false,
  accent:              "#f5a25d"
}
const DEFAULT_SETTINGS = { conserverOriginaux: false }

const MIN_VEIL            = 0.15
const MAX_VEIL            = 0.85
const MAX_IMAGE_LUMINANCE = 0.4
const IMAGE_EXTENSIONS    = ["jpg", "jpeg", "png", "webp", "gif", "avif"]
const FORBIDDEN_CHARACTERS = /[\\/:*?"<>|#^\[\]]/g
const OPENABLE_IN_OBSIDIAN = ["md", "pdf", "png", "jpg", "jpeg", "webp", "gif", "svg", "bmp", "avif"]
const MODAL_TRANSITION_MILLISECONDS = 240

const KINDS = {
  image:   { label: "Image",          tile: "IMG",  color: "#b9dcff", background: "rgba(124,196,255,.2)", category: "images" },
  svg:     { label: "Image vectorielle", tile: "SVG", color: "#b9dcff", background: "rgba(124,196,255,.2)", category: "images" },
  pdf:     { label: "PDF",            tile: "PDF",  color: "#ffc2bc", background: "rgba(255,138,128,.2)", category: "documents" },
  word:    { label: "Word",           tile: "W",    color: "#c3d0ff", background: "rgba(143,168,255,.22)", category: "documents" },
  note:    { label: "Note",           tile: "M",    color: "#e0ccff", background: "rgba(201,167,255,.2)", category: "documents" },
  html:    { label: "Page HTML",      tile: "</>",  color: "#ffd9a8", background: "rgba(245,162,93,.2)",  category: "documents" },
  csv:     { label: "CSV",            tile: "CSV",  color: "#b6f0cb", background: "rgba(111,220,154,.2)", category: "donnees" },
  xlsx:    { label: "Excel",          tile: "XLS",  color: "#b6f0cb", background: "rgba(111,220,154,.2)", category: "donnees" },
  json:    { label: "JSON",           tile: "{ }",  color: "#b6f0cb", background: "rgba(111,220,154,.2)", category: "donnees" },
  inconnu: { label: "Non pris en charge", tile: "?", color: "#c9ced4", background: "rgba(255,255,255,.1)", category: "autres" }
}

const FILTERS = [
  { id: "tous",      label: "Tous" },
  { id: "images",    label: "Images" },
  { id: "documents", label: "Documents" },
  { id: "donnees",   label: "Données" }
]

const CATEGORY_SOURCES = {
  images: {
    sources: [
      { label: "Image (PNG, JPG, WebP, GIF, BMP, AVIF, HEIC)", detection: { kind: "image", format: "autre" } },
      { label: "Image vectorielle (SVG)",                       detection: { kind: "svg",   format: "svg" } }
    ],
    groups: ["Plusieurs images → un seul PDF"]
  },
  documents: {
    sources: [
      { label: "PDF",            detection: { kind: "pdf",  format: "pdf" } },
      { label: "Word (DOCX)",    detection: { kind: "word", format: "word" } },
      { label: "Note (MD, TXT)", detection: { kind: "note", format: "note" } },
      { label: "Page HTML",      detection: { kind: "html", format: "html" } }
    ],
    groups: ["Plusieurs PDF → un PDF fusionné"]
  },
  donnees: {
    sources: [
      { label: "CSV",          detection: { kind: "csv",  format: "csv" } },
      { label: "Excel (XLSX)", detection: { kind: "xlsx", format: "xlsx" } },
      { label: "JSON",         detection: { kind: "json", format: "json" } }
    ],
    groups: []
  }
}

const ICONS = {
  logo:    "M3 7h13l-3-3M21 17H8l3 3",
  upload:  "M12 15V4M7 9l5-5 5 5M4 15v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-3",
  image:   "M3 6a3 3 0 0 1 3-3h12a3 3 0 0 1 3 3v12a3 3 0 0 1-3 3H6a3 3 0 0 1-3-3zM9 7a2 2 0 1 0 0 4 2 2 0 0 0 0-4zM21 15l-4.5-4.5L5 21",
  refresh: "M21 12a9 9 0 1 1-2.6-6.4M21 4v5h-5",
  check:   "M20 6 9 17l-5-5",
  close:   "M18 6 6 18M6 6l12 12",
  arrow:   "M5 12h14M13 6l6 6-6 6",
  trash:   "M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6M10 11v6M14 11v6"
}

const EMBERS_SVG = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1600 1000" preserveAspectRatio="xMidYMid slice">
<rect width="1600" height="1000" fill="#1c1410"/>
<circle cx="1250" cy="180" r="420" fill="#7a3b1c" opacity=".55"/><circle cx="300" cy="900" r="520" fill="#4a2a1a" opacity=".7"/>
<circle cx="900" cy="620" r="300" fill="#b8642a" opacity=".25"/><circle cx="1450" cy="850" r="260" fill="#2c1d16" opacity=".8"/>
</svg>`

const STYLE = `
.markdown-preview-view.cv { background-image: var(--cv-fond, none); background-size: cover; background-position: center; background-repeat: no-repeat; background-attachment: local; }
.markdown-preview-view.cv .markdown-preview-sizer { max-width: min(1240px, 100%); padding-bottom: 90px; }
.markdown-preview-view.cv .inline-title, .markdown-preview-view.cv .metadata-container { display: none; }
.markdown-preview-view.cv .callout { --callout-color: 255, 255, 255; background: rgba(16,18,24,.92); border: 1px solid rgba(255,255,255,.1); border-radius: 16px; color: #eef1f4; font-size: 13px; }
.cv-app { --cv-carte: rgba(13,15,21,.6); --cv-flou: 20px; --cv-accent: #f5a25d; container-type: inline-size; color: #eef1f4; font-family: "Geist", "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif; font-size: 13px; line-height: 1.4; display: flex; flex-direction: column; gap: 14px; margin: 8px 0 24px; text-shadow: 0 1px 2px rgba(0,0,0,.25); }
.cv-app * { box-sizing: border-box; }
.cv-app .cv-mono { font-family: "Geist Mono", "Cascadia Code", Consolas, monospace; font-variant-numeric: tabular-nums; }
.cv-app .cv-doux { color: rgba(238,241,244,.74); }
.cv-app .cv-verre { position: relative; isolation: isolate; border: 1px solid rgba(255,255,255,.09); border-radius: 16px; box-shadow: inset 0 1px 0 rgba(255,255,255,.06), 0 18px 44px rgba(0,0,0,.18); }
.cv-app .cv-verre::before { content: ""; position: absolute; inset: 0; z-index: -1; border-radius: inherit; background: var(--cv-carte); backdrop-filter: blur(var(--cv-flou)) saturate(140%); -webkit-backdrop-filter: blur(var(--cv-flou)) saturate(140%); }
.cv-app .cv-entete { display: flex; align-items: center; gap: 12px; padding: 12px 14px; }
.cv-app .cv-logo { width: 34px; height: 34px; border-radius: 10px; flex: none; display: flex; align-items: center; justify-content: center; background: color-mix(in srgb, var(--cv-accent) 18%, transparent); color: var(--cv-accent); }
.cv-app .cv-nom { font-size: 15px; font-weight: 600; white-space: nowrap; }
.cv-app .cv-depot { flex: 1; min-width: 0; height: 42px; margin-left: 8px; border: 1.5px dashed color-mix(in srgb, var(--cv-accent) 60%, transparent); border-radius: 11px; display: flex; align-items: center; gap: 10px; padding: 0 14px; color: rgba(238,241,244,.86); cursor: pointer; transition: background-color .18s ease, border-color .18s ease; }
.cv-app .cv-depot:hover { background: rgba(255,255,255,.05); }
.cv-app .cv-depot span { overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
.cv-app .cv-depot b { color: color-mix(in srgb, var(--cv-accent) 55%, #ffffff); font-weight: 600; }
.cv-app.cv-glisse .cv-depot { background: color-mix(in srgb, var(--cv-accent) 16%, transparent); border-color: var(--cv-accent); }
.cv-app.cv-glisse .cv-liste-carte { outline: 2px dashed var(--cv-accent); outline-offset: 4px; }
.cv-app button.cv-bouton { all: unset; box-sizing: border-box; display: inline-flex; align-items: center; justify-content: center; gap: 7px; height: 32px; padding: 0 13px; border-radius: 9px; border: 1px solid rgba(255,255,255,.15); background: rgba(255,255,255,.07); color: #eef1f4; font-weight: 600; cursor: pointer; white-space: nowrap; transition: background-color .18s ease, filter .18s ease; }
.cv-app button.cv-bouton:hover { background: rgba(255,255,255,.13); }
.cv-app button.cv-bouton.cv-principal { background: var(--cv-accent); border-color: var(--cv-accent); color: #1d1209; text-shadow: none; }
.cv-app button.cv-bouton.cv-principal:hover { filter: brightness(1.07); }
.cv-app button.cv-bouton.cv-icone { width: 34px; padding: 0; }
.cv-app button.cv-bouton:disabled { opacity: .45; cursor: default; }
.cv-app button:focus-visible, .cv-app select:focus-visible, .cv-app input:focus-visible, .cv-app .cv-depot:focus-visible { outline: 2px solid #ffffff; outline-offset: 2px; }
.cv-app .cv-barre { display: flex; align-items: center; gap: 6px; padding: 12px 14px; flex-wrap: wrap; }
.cv-app button.cv-onglet { all: unset; height: 30px; padding: 0 12px; border-radius: 8px; color: rgba(238,241,244,.76); font-weight: 600; cursor: pointer; }
.cv-app button.cv-onglet:hover { color: #ffffff; }
.cv-app button.cv-onglet.cv-actif { background: rgba(255,255,255,.11); color: #ffffff; }
.cv-app button.cv-onglet .cv-mono { margin-left: 6px; opacity: .75; font-size: 11.5px; }
.cv-app .cv-onglet-bloc { position: relative; display: inline-flex; }
.cv-app .cv-infobulle { position: absolute; top: calc(100% + 8px); left: 0; z-index: 30; width: min(380px, 86vw); padding: 12px 14px; border-radius: 12px; background: rgb(22,24,30); border: 1px solid rgba(255,255,255,.12); box-shadow: 0 16px 40px rgba(0,0,0,.45); display: flex; flex-direction: column; gap: 9px; text-shadow: none; opacity: 0; visibility: hidden; transform: translateY(-3px); transition: opacity .15s ease, transform .15s ease, visibility 0s linear .15s; pointer-events: none; }
.cv-app .cv-onglet-bloc:hover .cv-infobulle, .cv-app .cv-onglet-bloc:focus-within .cv-infobulle { opacity: 1; visibility: visible; transform: none; transition-delay: .25s, .25s, 0s; }
.cv-app .cv-infobulle b { font-size: 11px; letter-spacing: .08em; text-transform: uppercase; color: #8d969f; font-weight: 600; }
.cv-app .cv-infobulle div { display: flex; flex-direction: column; gap: 2px; }
.cv-app .cv-infobulle div span:first-child { font-weight: 600; color: #ffffff; }
.cv-app .cv-infobulle div span:last-child { color: rgba(238,241,244,.78); line-height: 1.4; }
.cv-app .cv-infobulle em { font-style: normal; color: color-mix(in srgb, var(--cv-accent) 60%, #ffffff); }
.cv-app .cv-ligne { display: grid; grid-template-columns: 36px minmax(0, 1fr) 128px 76px 16px 210px 176px 26px; gap: 12px; align-items: center; padding: 10px 14px; border-top: 1px solid rgba(255,255,255,.07); }
.cv-app .cv-ligne.cv-titres { font-size: 11px; font-weight: 600; letter-spacing: .05em; text-transform: uppercase; color: rgba(238,241,244,.6); padding-top: 8px; padding-bottom: 8px; }
.cv-app .cv-ligne.cv-fait { background: rgba(111,220,154,.07); }
.cv-app .cv-ligne.cv-echec { background: rgba(255,138,128,.07); }
.cv-app .cv-vignette { width: 34px; height: 34px; border-radius: 8px; display: flex; align-items: center; justify-content: center; font-size: 10px; font-weight: 700; background-size: cover; background-position: center; overflow: hidden; }
.cv-app .cv-fichier { display: flex; flex-direction: column; gap: 2px; min-width: 0; }
.cv-app .cv-fichier b { font-weight: 600; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.cv-app .cv-fichier span { font-size: 12px; color: rgba(238,241,244,.68); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.cv-app .cv-type { justify-self: start; border-radius: 6px; padding: 2px 7px; font-size: 12px; font-weight: 600; white-space: nowrap; max-width: 100%; overflow: hidden; text-overflow: ellipsis; }
.cv-app .cv-taille { color: rgba(238,241,244,.8); }
.cv-app .cv-fleche { color: rgba(238,241,244,.45); display: flex; }
.cv-app .cv-cible { display: flex; flex-direction: column; gap: 6px; min-width: 0; }
.cv-app select.cv-choix, .cv-app input.cv-champ { font: inherit; font-weight: 600; color: #eef1f4; background: rgba(255,255,255,.07); border: 1px solid rgba(255,255,255,.16); border-radius: 8px; height: 32px; padding: 0 8px; width: 100%; box-shadow: none; }
.cv-app select.cv-choix option { color: #1d1f23; }
.cv-app input.cv-champ { font-weight: 500; }
.cv-app input.cv-champ::placeholder { color: rgba(238,241,244,.5); }
.cv-app .cv-action { display: flex; align-items: center; gap: 10px; min-width: 0; font-weight: 600; }
.cv-app .cv-action a, .cv-app button.cv-lien { all: unset; color: color-mix(in srgb, var(--cv-accent) 50%, #ffffff); cursor: pointer; font-weight: 600; }
.cv-app .cv-action a:hover, .cv-app button.cv-lien:hover { color: #ffffff; text-decoration: underline; }
.cv-app .cv-progression { display: flex; flex-direction: column; gap: 4px; width: 100%; }
.cv-app .cv-progression span { font-size: 11px; color: rgba(238,241,244,.8); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.cv-app .cv-jauge { height: 5px; border-radius: 999px; background: rgba(255,255,255,.1); overflow: hidden; }
.cv-app .cv-jauge i { display: block; height: 100%; border-radius: 999px; background: var(--cv-accent); transition: width .2s ease; }
.cv-app .cv-jauge.cv-indefini i { width: 35%; animation: cv-glisse 1.1s ease-in-out infinite; }
.cv-app .cv-erreur { color: #ffc2bc; font-size: 12px; font-weight: 500; line-height: 1.3; }
.cv-app button.cv-retirer { all: unset; width: 26px; height: 26px; border-radius: 7px; display: flex; align-items: center; justify-content: center; color: rgba(238,241,244,.55); cursor: pointer; }
.cv-app button.cv-retirer:hover { background: rgba(255,255,255,.09); color: #ffffff; }
.cv-app button.cv-poubelle { all: unset; margin-left: auto; width: 26px; height: 26px; border-radius: 7px; display: flex; align-items: center; justify-content: center; color: rgba(238,241,244,.6); cursor: pointer; }
.cv-app button.cv-poubelle:hover { background: rgba(255,138,128,.16); color: #ffc2bc; }
.cv-app button.cv-bouton.cv-danger { background: #ff8a80; border-color: #ff8a80; color: #2a0d0a; text-shadow: none; }
.cv-app .cv-confirmer { display: flex; align-items: center; gap: 6px; white-space: nowrap; }
.cv-app .cv-confirmer button.cv-bouton { height: 28px; padding: 0 10px; }
.cv-app .cv-vide { padding: 48px 20px 56px; display: flex; flex-direction: column; align-items: center; gap: 10px; text-align: center; border-top: 1px solid rgba(255,255,255,.07); }
.cv-app .cv-vide b { font-size: 15px; font-weight: 600; }
.cv-app .cv-pied { display: flex; align-items: center; gap: 14px; flex-wrap: wrap; padding: 12px 14px; border-top: 1px solid rgba(255,255,255,.08); font-size: 12px; }
.cv-app .cv-reglage { display: flex; align-items: center; gap: 10px; color: #eef1f4; font-size: 13px; font-weight: 600; }
.cv-app button.cv-interrupteur { all: unset; box-sizing: border-box; flex: none; width: 34px; height: 20px; padding: 2px; border-radius: 10px; display: flex; background: rgba(255,255,255,.25); cursor: pointer; transition: background-color .2s ease; }
.cv-app button.cv-interrupteur i { width: 16px; height: 16px; border-radius: 50%; background: #ffffff; }
.cv-app button.cv-interrupteur.cv-actif { background: var(--cv-accent); justify-content: flex-end; }
.cv-app .cv-statut:empty { display: none; }
.cv-app .cv-statut { color: #ffffff; font-weight: 500; }
.cv-app .cv-texte-court { display: none; }
@keyframes cv-glisse { from { transform: translateX(-100%); } to { transform: translateX(300%); } }
@container (max-width: 820px) {
  .cv-app .cv-ligne { grid-template-columns: 36px minmax(0, 1fr) 26px; row-gap: 8px; }
  .cv-app .cv-ligne.cv-titres { display: none; }
  .cv-app .cv-type, .cv-app .cv-taille, .cv-app .cv-fleche { display: none; }
  .cv-app .cv-cible { grid-column: 1 / 3; grid-row: 2; }
  .cv-app .cv-action { grid-column: 3 / 4; grid-row: 2; justify-content: flex-end; }
  .cv-app .cv-ligne > .cv-action:has(.cv-progression), .cv-app .cv-ligne > .cv-action:has(.cv-erreur), .cv-app .cv-ligne.cv-fait > .cv-action { grid-column: 1 / -1; grid-row: 3; justify-content: flex-start; }
  .cv-app .cv-ligne > .cv-action:has(> button) { grid-column: 3 / -1; }
  .cv-app .cv-ligne { grid-template-columns: 36px minmax(0, 1fr) auto; }
  .cv-app button.cv-retirer { grid-column: 3; grid-row: 1; justify-self: end; }
  .cv-app .cv-entete { flex-wrap: wrap; }
  .cv-app .cv-nom { flex: 1; }
  .cv-app .cv-depot { order: 5; flex: 1 1 100%; margin-left: 0; justify-content: center; }
  .cv-app .cv-texte-large { display: none; }
  .cv-app .cv-texte-court { display: inline; }
}
@media (prefers-reduced-motion: reduce) { .cv-app *, .cv-modale, .cv-modale * { transition: none !important; animation: none !important; } }
.cv-modale { position: fixed; inset: 0; z-index: 60; display: flex; align-items: center; justify-content: center; padding: 24px; background: rgba(6,8,12,.55); opacity: 0; pointer-events: none; transition: opacity .22s ease; }
.cv-modale.cv-ouvert { opacity: 1; pointer-events: auto; }
.cv-modale .cv-fenetre { width: min(760px, 100%); max-height: calc(100vh - 48px); overflow-y: auto; margin: 0; transform: translateY(12px) scale(.98); transition: transform .26s cubic-bezier(.2,.8,.2,1); background: rgb(20,22,28); border: 1px solid rgba(255,255,255,.1); border-radius: 22px; box-shadow: 0 40px 100px rgba(0,0,0,.5); color: #eef1f4; font-family: "Geist", "Segoe UI Variable Text", "Segoe UI", system-ui, sans-serif; font-size: 13px; }
.cv-modale.cv-ouvert .cv-fenetre { transform: none; }
.cv-modale * { box-sizing: border-box; }
.cv-modale .cv-doux { color: #a9b1ba; }
.cv-modale .cv-modale-tete { display: flex; align-items: center; gap: 12px; padding: 24px 28px 6px; }
.cv-modale .cv-modale-tete b { font-size: 18px; font-weight: 600; color: #ffffff; }
.cv-modale .cv-section { display: flex; flex-direction: column; gap: 16px; padding: 22px 28px; border-top: 1px solid rgba(255,255,255,.06); }
.cv-modale .cv-section:first-of-type { border-top: 0; }
.cv-modale .cv-section-titre { font-size: 11px; letter-spacing: .14em; font-weight: 600; color: #8d969f; text-transform: uppercase; }
.cv-modale .cv-fonds { display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 16px; }
.cv-modale .cv-miniature { all: unset; box-sizing: border-box; display: flex; flex-direction: column; gap: 8px; cursor: pointer; font-size: 12.5px; color: #cfd5dc; }
.cv-modale .cv-miniature span:first-child { display: block; height: 92px; border-radius: 14px; background-size: cover; background-position: center; outline: 1px solid rgba(255,255,255,.25); outline-offset: 3px; transition: transform .18s ease; }
.cv-modale .cv-miniature:hover span:first-child { transform: translateY(-2px); }
.cv-modale .cv-miniature span:last-child { white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.cv-modale .cv-miniature.cv-choisi span:first-child { outline: 2px solid #ffffff; }
.cv-modale .cv-miniature.cv-choisi span:last-child { color: #ffffff; font-weight: 500; }
.cv-modale .cv-miniature.cv-aucun span:first-child { background: repeating-linear-gradient(45deg, rgba(255,255,255,.08) 0 8px, rgba(255,255,255,.02) 8px 16px); }
.cv-modale .cv-ajout { box-sizing: border-box; height: 92px; border-radius: 14px; border: 1.5px dashed rgba(255,255,255,.45); display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 6px; cursor: pointer; font-size: 12.5px; color: #eef1f4; }
.cv-modale .cv-ajout:hover { background: rgba(255,255,255,.05); }
.cv-modale .cv-curseur { display: grid; grid-template-columns: 200px 1fr 56px; align-items: center; gap: 16px; }
.cv-modale .cv-curseur .cv-valeur { text-align: right; color: #a9b1ba; font-family: "Geist Mono", Consolas, monospace; }
.cv-modale input[type=range] { -webkit-appearance: none; appearance: none; width: 100%; height: 4px; border-radius: 2px; background: rgba(255,255,255,.16); outline: none; margin: 0; border: 0; box-shadow: none; }
.cv-modale input[type=range]::-webkit-slider-thumb { -webkit-appearance: none; width: 18px; height: 18px; border-radius: 50%; background: #ffffff; border: 0; cursor: pointer; box-shadow: 0 1px 6px rgba(0,0,0,.45); }
.cv-modale input[type=range]:disabled { opacity: .35; }
.cv-modale .cv-reglage { display: flex; align-items: center; gap: 10px; }
.cv-modale .cv-reglage > span { display: flex; flex-direction: column; gap: 2px; }
.cv-modale .cv-reglage b { font-weight: 500; }
.cv-modale button.cv-interrupteur { all: unset; box-sizing: border-box; margin-left: auto; flex: none; width: 34px; height: 20px; padding: 2px; border-radius: 10px; display: flex; background: rgba(255,255,255,.25); cursor: pointer; }
.cv-modale button.cv-interrupteur i { width: 16px; height: 16px; border-radius: 50%; background: #ffffff; }
.cv-modale button.cv-interrupteur.cv-actif { background: var(--cv-accent); justify-content: flex-end; }
.cv-modale .cv-pied-modale { display: flex; padding: 18px 28px 24px; border-top: 1px solid rgba(255,255,255,.06); }
.cv-modale button.cv-fermer { all: unset; margin-left: auto; width: 34px; height: 34px; border-radius: 10px; display: flex; align-items: center; justify-content: center; cursor: pointer; color: #cfd5dc; }
.cv-modale button.cv-fermer:hover { background: rgba(255,255,255,.08); color: #ffffff; }
.cv-modale button.cv-termine { all: unset; margin-left: auto; height: 36px; padding: 0 18px; border-radius: 10px; background: var(--cv-accent); color: #1d1209; font-weight: 600; cursor: pointer; }
.cv-modale button:focus-visible { outline: 2px solid #ffffff; outline-offset: 2px; }
@media (max-width: 640px) { .cv-modale .cv-curseur { grid-template-columns: 1fr 56px; } .cv-modale .cv-curseur input { grid-column: 1 / -1; grid-row: 2; } }
`


// ---------- Outils ----------

function escapeHtml(text) {
  const value   = String(text ?? "")
  const escaped = value.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;")
  return escaped
}


function icon(name, size) {
  const width = size ?? 16
  return `<svg width="${width}" height="${width}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="${ICONS[name]}"/></svg>`
}


function formatSize(bytes) {
  const KILO = 1024
  if (bytes < KILO) return bytes + " o"
  if (bytes < KILO * KILO) return Math.round(bytes / KILO) + " Ko"
  const megabytes = bytes / KILO / KILO
  return megabytes.toLocaleString("fr-FR", { maximumFractionDigits: 1 }) + " Mo"
}


function splitName(name) {
  const dotIndex  = name.lastIndexOf(".")
  const hasDot    = dotIndex > 0
  const base      = hasDot ? name.slice(0, dotIndex) : name
  const extension = hasDot ? name.slice(dotIndex + 1) : ""
  return { base, extension }
}


function safeName(name) {
  return name.replace(FORBIDDEN_CHARACTERS, "-").trim() || "fichier"
}


async function readJson(path, fallback) {
  const exists = await app.vault.adapter.exists(path)
  if (!exists) return fallback
  try {
    const raw = await app.vault.adapter.read(path)
    return JSON.parse(raw.replace(/^﻿/, ""))
  } catch (error) {
    return fallback
  }
}


async function writeJson(path, data) {
  const content = JSON.stringify(data, null, 2) + "\n"
  await app.vault.adapter.write(path, content)
}


async function ensureFolder(path) {
  const exists = await app.vault.adapter.exists(path)
  if (!exists) await app.vault.adapter.mkdir(path)
}


async function uniquePath(folder, base, extension) {
  let counter   = 1
  let candidate = folder + "/" + base + (extension ? "." + extension : "")
  while (await app.vault.adapter.exists(candidate)) {
    counter++
    candidate = folder + "/" + base + " (" + counter + ")" + (extension ? "." + extension : "")
  }
  return candidate
}


async function chooseBaseName(base, extension) {
  let counter   = 1
  let candidate = base
  const taken   = async name => (await app.vault.adapter.exists(OUTPUT_FOLDER + "/" + name + "." + extension)) || (await app.vault.adapter.exists(OUTPUT_FOLDER + "/" + name + " - pages")) || (await app.vault.adapter.exists(OUTPUT_FOLDER + "/" + name + " - images"))
  while (await taken(candidate)) {
    counter++
    candidate = base + " (" + counter + ")"
  }
  return candidate
}


function getNodeModules() {
  const nodeRequire = window.require
  if (typeof nodeRequire !== "function") return null
  try {
    return { electron: nodeRequire("electron"), path: nodeRequire("path") }
  } catch (error) {
    return null
  }
}


// ---------- Bibliothèques et moteur ----------

async function loadLibrary(fileName, globalName) {
  const cache = window.cvBibliotheques ?? {}
  window.cvBibliotheques = cache
  if (cache[fileName]) return cache[fileName]
  const path      = LIBRARY_FOLDER + "/" + fileName
  const exists    = await app.vault.adapter.exists(path)
  if (!exists) throw new Error("Bibliothèque manquante : " + fileName + " (voir Santé du vault).")
  const code      = await app.vault.adapter.read(path)
  const lookup    = "\n;return (typeof " + globalName + " !== 'undefined') ? " + globalName + " : globalThis." + globalName
  const factory   = new Function("module", "exports", "define", "require", code + lookup)
  const library   = factory.call(globalThis, undefined, undefined, undefined, undefined)
  if (!library) throw new Error("Bibliothèque illisible : " + fileName)
  cache[fileName] = library
  return library
}
loadLibrary.folder = LIBRARY_FOLDER


async function loadEngine() {
  const code    = await app.vault.adapter.read(ENGINE_PATH)
  const factory = new Function("app", "loadLibrary", code)
  return factory(app, loadLibrary)
}


// ---------- Fond et transparence ----------

async function listBackgroundImages() {
  const exists = await app.vault.adapter.exists(BACKGROUND_FOLDER)
  if (!exists) return []
  const listing = await app.vault.adapter.list(BACKGROUND_FOLDER)
  const images  = listing.files.filter(file => IMAGE_EXTENSIONS.includes(file.split(".").pop().toLowerCase()))
  return images
}


function getBackgroundUrl(background) {
  if (!background || background === "aucun") return null
  if (background === "braises") return "data:image/svg+xml;charset=utf-8," + encodeURIComponent(EMBERS_SVG)
  const path = APP_FOLDER + "/" + background
  return app.vault.adapter.getResourcePath(path)
}


function loadImage(url) {
  return new Promise((resolve, reject) => {
    const image   = new Image()
    image.onload  = () => resolve(image)
    image.onerror = reject
    image.src     = url
  })
}


function toLinear(channel) {
  const value = channel / 255
  return value <= 0.03928 ? value / 12.92 : Math.pow((value + 0.055) / 1.055, 2.4)
}


async function measureLuminance(url) {
  const SAMPLE_SIZE = 48
  const PERCENTILE  = 0.9
  try {
    const image   = await loadImage(url)
    const canvas  = document.createElement("canvas")
    canvas.width  = SAMPLE_SIZE
    canvas.height = SAMPLE_SIZE
    const context = canvas.getContext("2d")
    context.drawImage(image, 0, 0, SAMPLE_SIZE, SAMPLE_SIZE)
    const pixels     = context.getImageData(0, 0, SAMPLE_SIZE, SAMPLE_SIZE).data
    const luminances = []
    for (let index = 0; index < pixels.length; index += 4) {
      const luminance = 0.2126 * toLinear(pixels[index]) + 0.7152 * toLinear(pixels[index + 1]) + 0.0722 * toLinear(pixels[index + 2])
      luminances.push(luminance)
    }
    const sorted = luminances.sort((first, second) => first - second)
    return sorted[Math.floor(sorted.length * PERCENTILE)]
  } catch (error) {
    return null
  }
}


function computeVeil(appearance, luminance) {
  if (appearance.voile !== "auto") return Number(appearance.voile)
  if (luminance === null) return 0.4
  const needed  = 1 - MAX_IMAGE_LUMINANCE / Math.max(luminance, 0.0001)
  const clamped = Math.min(MAX_VEIL, Math.max(MIN_VEIL, needed))
  return Math.round(clamped * 100) / 100
}


function applyCardStyle(root, appearance) {
  const cardColor = appearance.reduireTransparence ? "rgb(22,25,32)" : `rgba(13,15,21,${appearance.teinte})`
  const blur      = appearance.reduireTransparence ? 0 : appearance.flou
  root.style.setProperty("--cv-carte", cardColor)
  root.style.setProperty("--cv-flou", blur + "px")
  root.style.setProperty("--cv-accent", appearance.accent)
}


function applyBackground(viewElement, appearance, veil) {
  if (!viewElement) return
  const url = getBackgroundUrl(appearance.fond)
  if (!url) {
    viewElement.style.setProperty("--cv-fond", "none")
    return
  }
  const darkening = Math.min(0.9, Math.max(0, Number(appearance.assombrir) || 0))
  const total     = Math.round((1 - (1 - veil) * (1 - darkening)) * 100) / 100
  const layer     = `linear-gradient(rgba(8,8,16,${total}), rgba(8,8,16,${total})), url("${url}")`
  viewElement.style.setProperty("--cv-fond", layer)
}


async function addBackgroundImage(file) {
  await ensureFolder(BACKGROUND_FOLDER)
  const target = BACKGROUND_FOLDER + "/" + safeName(file.name)
  const buffer = await file.arrayBuffer()
  await app.vault.adapter.writeBinary(target, buffer)
  return target.slice(APP_FOLDER.length + 1)
}


function renderAppearancePanel(appearance, images, veil) {
  const presets = [
    { value: "aucun",   label: "Fond général d'Obsidian", style: "", extraClass: "cv-aucun" },
    { value: "braises", label: "Braises", style: `background-image:url('${getBackgroundUrl("braises")}')`, extraClass: "" }
  ]
  const customs = images.map(path => {
    const relative = path.slice(APP_FOLDER.length + 1)
    const name     = relative.split("/").pop().replace(/\.[^.]+$/, "")
    return { value: relative, label: name, style: `background-image:url('${app.vault.adapter.getResourcePath(path)}')`, extraClass: "" }
  })
  const options = [...presets, ...customs].map(option => {
    const chosen = option.value === appearance.fond ? "cv-choisi" : ""
    return `<button type="button" class="cv-miniature ${option.extraClass} ${chosen}" data-fond="${escapeHtml(option.value)}" title="${escapeHtml(option.label)}"><span style="${option.style}"></span><span>${escapeHtml(option.label)}</span></button>`
  }).join("")
  const opacity  = Math.round(appearance.teinte * 100)
  const blur     = Math.round(appearance.flou)
  const darken   = Math.round((Number(appearance.assombrir) || 0) * 100)
  const noImage  = appearance.fond === "aucun" ? "disabled" : ""
  const locked   = appearance.reduireTransparence ? "disabled" : ""
  const veilText = appearance.fond === "aucun" ? "Fond général : pas de voile." : "Voile " + (appearance.voile === "auto" ? "automatique : " : ": ") + Math.round(veil * 100) + " %, pour un contraste du texte d'au moins 4,5 : 1."
  return `<div class="cv-modale-tete"><span style="display:flex;flex-direction:column;gap:4px"><b>Fond et transparence</b><span class="cv-doux">S'applique à cette application seulement.</span></span><button type="button" class="cv-fermer" data-action="fermer" aria-label="Fermer">${icon("close", 18)}</button></div>
    <div class="cv-section">
      <span class="cv-section-titre">Fond</span>
      <div class="cv-fonds">${options}
        <label class="cv-ajout">${icon("image", 20)}<span>Ajouter une image</span><input type="file" accept="image/*" data-action="ajout-fond" style="display:none"></label>
      </div>
      <span class="cv-doux">Les images ajoutées sont copiées dans « ${escapeHtml(BACKGROUND_FOLDER)} ».</span>
      <div class="cv-curseur"><label for="cv-assombrir">Assombrir l'image</label><input id="cv-assombrir" type="range" min="0" max="70" step="1" value="${darken}" data-reglage="assombrir" ${noImage}><span class="cv-valeur" data-valeur="assombrir">${darken} %</span></div>
    </div>
    <div class="cv-section">
      <span class="cv-section-titre">Cartes</span>
      <div class="cv-curseur"><label for="cv-opacite">Opacité</label><input id="cv-opacite" type="range" min="30" max="90" step="1" value="${opacity}" data-reglage="teinte" ${locked}><span class="cv-valeur" data-valeur="teinte">${opacity} %</span></div>
      <div class="cv-curseur"><label for="cv-flou">Flou de l'arrière-plan</label><input id="cv-flou" type="range" min="0" max="40" step="1" value="${blur}" data-reglage="flou" ${locked}><span class="cv-valeur" data-valeur="flou">${blur} px</span></div>
    </div>
    <div class="cv-section">
      <span class="cv-section-titre">Lisibilité</span>
      <div class="cv-reglage"><span><b>Réduire la transparence</b><span class="cv-doux">Cartes opaques, sans flou</span></span><button type="button" class="cv-interrupteur ${appearance.reduireTransparence ? "cv-actif" : ""}" role="switch" aria-checked="${appearance.reduireTransparence}" aria-label="Réduire la transparence" data-action="transparence"><i></i></button></div>
      <span class="cv-doux">${escapeHtml(veilText)}</span>
    </div>
    <div class="cv-pied-modale"><button type="button" class="cv-termine" data-action="fermer">Terminé</button></div>`
}


function closeModal(context, animated) {
  const overlay = context.modal
  if (context.modalKeys) document.removeEventListener("keydown", context.modalKeys)
  context.modal     = null
  context.modalKeys = null
  if (!overlay) return
  if (!animated) { overlay.remove(); return }
  overlay.classList.remove("cv-ouvert")
  setTimeout(() => overlay.remove(), MODAL_TRANSITION_MILLISECONDS)
}


async function openAppearancePanel(context) {
  const appearance = context.appearance
  const images     = await listBackgroundImages()
  const veil       = context.veil
  let overlay      = context.modal
  let frame        = overlay ? overlay.querySelector(".cv-fenetre") : null
  if (!overlay) {
    overlay = document.body.createDiv({ cls: "cv-modale" })
    frame   = overlay.createDiv({ cls: "cv-fenetre" })
    frame.setAttribute("role", "dialog")
    frame.setAttribute("aria-modal", "true")
    frame.setAttribute("aria-label", "Fond et transparence")
    context.modal     = overlay
    context.modalKeys = event => { if (event.key === "Escape") closeModal(context, true) }
    document.addEventListener("keydown", context.modalKeys)
    overlay.addEventListener("click", event => { if (event.target === overlay) closeModal(context, true) })
    setTimeout(() => overlay.classList.add("cv-ouvert"), 20)
  }
  frame.style.setProperty("--cv-accent", appearance.accent)
  frame.innerHTML = renderAppearancePanel(appearance, images, veil)

  const refresh = async () => {
    await applyAppearance(context)
    await openAppearancePanel(context)
  }
  frame.querySelectorAll("[data-action=fermer]").forEach(button => button.addEventListener("click", () => closeModal(context, true)))
  frame.querySelectorAll("[data-reglage]").forEach(input => {
    const key = input.getAttribute("data-reglage")
    input.addEventListener("input", () => {
      const value     = Number(input.value)
      const isPercent = key === "teinte" || key === "assombrir"
      appearance[key] = isPercent ? value / 100 : value
      frame.querySelector(`[data-valeur="${key}"]`).textContent = isPercent ? value + " %" : value + " px"
      if (key === "assombrir") applyBackground(context.viewElement, appearance, context.veil)
      else applyCardStyle(context.root, appearance)
    })
    input.addEventListener("change", () => writeJson(APPEARANCE_PATH, appearance))
  })
  frame.querySelectorAll("[data-fond]").forEach(element => {
    element.addEventListener("click", async () => {
      appearance.fond = element.getAttribute("data-fond")
      await writeJson(APPEARANCE_PATH, appearance)
      await refresh()
    })
  })
  frame.querySelector("[data-action=ajout-fond]").addEventListener("change", async event => {
    const file = event.target.files && event.target.files[0]
    if (!file) return
    appearance.fond = await addBackgroundImage(file)
    await writeJson(APPEARANCE_PATH, appearance)
    await refresh()
  })
  frame.querySelector("[data-action=transparence]").addEventListener("click", async () => {
    appearance.reduireTransparence = !appearance.reduireTransparence
    await writeJson(APPEARANCE_PATH, appearance)
    await refresh()
  })
}


async function applyAppearance(context) {
  const appearance    = context.appearance
  const backgroundUrl = getBackgroundUrl(appearance.fond)
  const luminance     = backgroundUrl ? await measureLuminance(backgroundUrl) : null
  const veil          = computeVeil(appearance, luminance)
  context.veil        = veil
  applyBackground(context.viewElement, appearance, veil)
  applyCardStyle(context.root, appearance)
  context.root.classList.toggle("ln-transparent", appearance.fond === "aucun")
}


// ---------- Fichiers à convertir ----------

async function getBytes(entry) {
  if (entry.bytes) return entry.bytes
  const buffer = entry.source === "inbox" ? await app.vault.adapter.readBinary(entry.path) : await entry.file.arrayBuffer()
  entry.bytes  = new Uint8Array(buffer)
  return entry.bytes
}


function previewUrl(entry) {
  const isPicture = entry.detection.kind === "image" || entry.detection.kind === "svg"
  const isHeic    = entry.detection.format === "heic"
  if (!isPicture || isHeic) return null
  if (entry.source === "inbox") return app.vault.adapter.getResourcePath(entry.path)
  if (!entry.objectUrl) entry.objectUrl = URL.createObjectURL(entry.file)
  return entry.objectUrl
}


async function createEntry(context, description) {
  const bytes     = description.bytes
  const detection = context.engine.detectKind(bytes, description.name)
  const entry     = {
    id:        ++context.lastId,
    name:      description.name,
    size:      description.size,
    source:    description.source,
    path:      description.path ?? null,
    file:      description.file ?? null,
    bytes:     description.source === "externe" ? bytes : null,
    detection,
    target:    context.engine.getDefaultTarget(detection),
    pages:     "",
    status:    detection.kind === "inconnu" ? "impossible" : "attente",
    details:   "",
    progress:  0,
    stepText:  "",
    outputs:   [],
    error:     detection.message ?? ""
  }
  entry.details = await context.engine.describe(bytes, detection)
  return entry
}


async function scanInbox(context) {
  await ensureFolder(INBOX_FOLDER)
  const listing = await app.vault.adapter.list(INBOX_FOLDER)
  const paths   = listing.files.filter(path => !path.split("/").pop().startsWith("."))
  const known   = new Set(context.entries.filter(entry => entry.source === "inbox").map(entry => entry.path))
  context.entries = context.entries.filter(entry => entry.source !== "inbox" || entry.status !== "attente" || paths.includes(entry.path))
  for (const path of paths) {
    if (known.has(path)) continue
    const buffer = await app.vault.adapter.readBinary(path)
    const bytes  = new Uint8Array(buffer)
    const entry  = await createEntry(context, { name: path.split("/").pop(), size: bytes.byteLength, source: "inbox", path, bytes })
    context.entries.push(entry)
  }
}


async function addExternalFiles(context, fileList) {
  const files = Array.from(fileList ?? [])
  for (const file of files) {
    const buffer = await file.arrayBuffer()
    const bytes  = new Uint8Array(buffer)
    const entry  = await createEntry(context, { name: file.name, size: file.size, source: "externe", file, bytes })
    context.entries.push(entry)
  }
}


// ---------- Écriture des résultats et originaux ----------

async function writeOutputs(outputs) {
  const written = []
  for (const output of outputs) {
    const fullPath = OUTPUT_FOLDER + "/" + output.relativePath
    const folder   = fullPath.slice(0, fullPath.lastIndexOf("/"))
    await ensureFolder(folder)
    if (typeof output.data === "string") await app.vault.adapter.write(fullPath, output.data)
    else await app.vault.adapter.writeBinary(fullPath, output.data.buffer.slice(output.data.byteOffset, output.data.byteOffset + output.data.byteLength))
    written.push(fullPath)
  }
  return written
}


async function handleOriginal(context, entry) {
  const keep = context.settings.conserverOriginaux
  if (keep) {
    await ensureFolder(ORIGINALS_FOLDER)
    const parts  = splitName(entry.name)
    const target = await uniquePath(ORIGINALS_FOLDER, safeName(parts.base), parts.extension)
    if (entry.source === "inbox") {
      const file = app.vault.getAbstractFileByPath(entry.path)
      if (file) await app.vault.rename(file, target)
      else await app.vault.adapter.rename(entry.path, target)
    } else {
      const bytes = await getBytes(entry)
      await app.vault.adapter.writeBinary(target, bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength))
    }
    entry.originalPath = target
    return
  }
  if (entry.source !== "inbox") return
  const file = app.vault.getAbstractFileByPath(entry.path)
  if (file) await app.vault.trash(file, false)
  else await app.vault.adapter.trashLocal(entry.path)
}


// Met à la corbeille d'Obsidian les fichiers produits par une conversion.
// Un dossier de sortie (« <nom> - pages », « <nom> - images ») part en entier.
async function trashOutputs(outputs) {
  const prefix   = OUTPUT_FOLDER + "/"
  const topItems = new Set()
  for (const path of outputs) {
    const relative   = path.startsWith(prefix) ? path.slice(prefix.length) : path
    const firstPart  = relative.split("/")[0]
    const isInFolder = relative.includes("/")
    topItems.add(isInFolder ? prefix + firstPart : path)
  }
  for (const path of topItems) {
    const exists = await app.vault.adapter.exists(path)
    if (!exists) continue
    const item = app.vault.getAbstractFileByPath(path)
    if (item) await app.vault.trash(item, false)
    else await app.vault.adapter.trashLocal(path)
  }
}


async function deleteConverted(context, entry) {
  const outputs = entry.outputs
  const sharing = context.entries.filter(candidate => candidate.status === "termine" && candidate.outputs.some(path => outputs.includes(path)))
  try {
    await trashOutputs(outputs)
    const removedIds = new Set(sharing.map(candidate => candidate.id))
    context.entries  = context.entries.filter(candidate => !removedIds.has(candidate.id))
    renderList(context)
    setStatus(context, "Fichier converti mis à la corbeille d'Obsidian.")
  } catch (error) {
    entry.confirmDelete = false
    renderList(context)
    setStatus(context, "Suppression impossible : " + readableError(error))
  }
}


// ---------- Conversions ----------

function updateProgress(context, entry) {
  const row = context.root.querySelector(`[data-ligne="${entry.id}"]`)
  if (!row) return
  const bar  = row.querySelector(".cv-jauge i")
  const text = row.querySelector(".cv-progression span")
  if (bar && entry.progress > 0) { bar.parentElement.classList.remove("cv-indefini"); bar.style.width = Math.round(entry.progress * 100) + "%" }
  if (text) text.textContent = entry.stepText || "Conversion…"
}


function readableError(error) {
  const message = error && error.message ? error.message : String(error)
  return message.length > 140 ? message.slice(0, 140) + "…" : message
}


async function convertEntry(context, entry) {
  if (entry.status === "en-cours" || entry.status === "impossible" || !entry.target) return
  const targets   = context.engine.getTargets(entry.detection)
  const target    = targets.find(candidate => candidate.id === entry.target)
  entry.status    = "en-cours"
  entry.progress  = 0
  entry.stepText  = "Conversion…"
  entry.error     = ""
  renderList(context)
  try {
    await ensureFolder(OUTPUT_FOLDER)
    const bytes    = await getBytes(entry)
    const baseRaw  = safeName(splitName(entry.name).base) + target.suffix
    const baseName = await chooseBaseName(baseRaw, target.extension)
    const outputs  = await context.engine.convert({
      bytes,
      detection:    entry.detection,
      targetId:     entry.target,
      baseName,
      pages:        entry.pages,
      outputFolder: OUTPUT_FOLDER,
      sourcePath:   entry.source === "inbox" ? entry.path : "",
      onProgress:   (share, text) => { entry.progress = share; entry.stepText = text; updateProgress(context, entry) }
    })
    entry.outputs  = await writeOutputs(outputs)
    entry.outputLabel = target.label
    await handleOriginal(context, entry)
    entry.status   = "termine"
    entry.bytes    = null
  } catch (error) {
    entry.status = "erreur"
    entry.error  = readableError(error)
  }
  renderList(context)
}


async function convertGroup(context, kindFilter, engineFunction, suffix) {
  const members = context.entries.filter(entry => kindFilter(entry) && (entry.status === "attente" || entry.status === "erreur"))
  if (members.length < 2) return
  members.forEach(entry => { entry.status = "en-cours"; entry.stepText = "Assemblage…"; entry.error = "" })
  renderList(context)
  try {
    await ensureFolder(OUTPUT_FOLDER)
    const items    = []
    for (const entry of members) items.push({ bytes: await getBytes(entry), detection: entry.detection })
    const baseRaw  = safeName(splitName(members[0].name).base) + suffix
    const baseName = await chooseBaseName(baseRaw, "pdf")
    const outputs  = await engineFunction(items, baseName)
    const written  = await writeOutputs(outputs)
    for (const entry of members) {
      entry.outputs     = written
      entry.outputLabel = "PDF commun"
      await handleOriginal(context, entry)
      entry.status      = "termine"
      entry.bytes       = null
    }
  } catch (error) {
    members.forEach(entry => { entry.status = "erreur"; entry.error = readableError(error) })
  }
  renderList(context)
}


async function convertVisible(context) {
  const visible = filterEntries(context).filter(entry => entry.status === "attente" || entry.status === "erreur")
  for (const entry of visible) await convertEntry(context, entry)
}


// ---------- Ouvrir les résultats ----------

async function openPath(context, path) {
  const extension = path.split(".").pop().toLowerCase()
  if (OPENABLE_IN_OBSIDIAN.includes(extension)) {
    await app.workspace.openLinkText(path, "", "tab")
    return
  }
  if (typeof app.openWithDefaultApp === "function") { app.openWithDefaultApp(path); return }
  const modules = context.modules
  if (modules) modules.electron.shell.openPath(modules.path.join(app.vault.adapter.basePath, path))
}


function revealPath(context, path) {
  const modules = context.modules
  const exists  = Boolean(app.vault.getAbstractFileByPath(path))
  if (typeof app.showInFolder === "function" && exists) { app.showInFolder(path); return }
  if (modules && app.vault.adapter.basePath) {
    const fullPath = modules.path.join(app.vault.adapter.basePath, path)
    modules.electron.shell.showItemInFolder(fullPath)
    return
  }
  const explorer = app.internalPlugins?.getPluginById?.("file-explorer")?.instance
  const item     = app.vault.getAbstractFileByPath(path)
  if (explorer && item) explorer.revealInFolder(item)
}


async function openFolder(context, folder) {
  await ensureFolder(folder)
  const modules = context.modules
  if (modules && app.vault.adapter.basePath) {
    modules.electron.shell.openPath(modules.path.join(app.vault.adapter.basePath, folder))
    return
  }
  const explorer = app.internalPlugins?.getPluginById?.("file-explorer")?.instance
  const item     = app.vault.getAbstractFileByPath(folder)
  if (explorer && item) explorer.revealInFolder(item)
}


// ---------- Affichage ----------

function filterEntries(context) {
  if (context.filter === "tous") return context.entries
  return context.entries.filter(entry => KINDS[entry.detection.kind].category === context.filter)
}


function renderConversionTooltip(context, categoryId) {
  const category = CATEGORY_SOURCES[categoryId]
  if (!category) return ""
  const rows = category.sources.map(source => {
    const targets = context.engine.getTargets(source.detection).map(target => target.label.replace(/…$/, ""))
    return `<div><span>${escapeHtml(source.label)}</span><span>→ ${escapeHtml(targets.join(" · "))}</span></div>`
  }).join("")
  const groups = category.groups.map(text => `<div><span><em>${escapeHtml(text)}</em></span></div>`).join("")
  return `<span class="cv-infobulle" role="tooltip" id="cv-infobulle-${categoryId}"><b>Conversions possibles</b>${rows}${groups}</span>`
}


function renderTile(entry) {
  const kind = KINDS[entry.detection.kind]
  const url  = previewUrl(entry)
  if (url) return `<span class="cv-vignette" style="background-image:url('${escapeHtml(url)}');background-color:rgba(255,255,255,.08)"></span>`
  return `<span class="cv-vignette" style="background:${kind.background};color:${kind.color}">${escapeHtml(kind.tile)}</span>`
}


function renderTarget(context, entry) {
  if (entry.status === "impossible") return `<span class="cv-doux">—</span>`
  if (entry.status === "termine") return `<span style="font-weight:600">${escapeHtml(entry.outputLabel ?? "")}</span>`
  const targets  = context.engine.getTargets(entry.detection)
  const disabled = entry.status === "en-cours" ? "disabled" : ""
  const options  = targets.map(target => `<option value="${target.id}" ${target.id === entry.target ? "selected" : ""}>${escapeHtml(target.label)}</option>`).join("")
  const pages    = entry.target === "extraire" ? `<input class="cv-champ" type="text" data-pages="${entry.id}" value="${escapeHtml(entry.pages)}" placeholder="Pages, par exemple 1-3, 5" aria-label="Pages à extraire" ${disabled}>` : ""
  return `<select class="cv-choix" data-cible="${entry.id}" aria-label="Format pour ${escapeHtml(entry.name)}" ${disabled}>${options}</select>${pages}`
}


function renderAction(entry) {
  if (entry.status === "impossible") return `<span class="cv-erreur">${escapeHtml(entry.error)}</span>`
  if (entry.status === "en-cours") {
    const width    = Math.round(entry.progress * 100)
    const pending  = entry.progress > 0 ? "" : "cv-indefini"
    const barStyle = entry.progress > 0 ? `style="width:${width}%"` : ""
    return `<div class="cv-progression"><span>${escapeHtml(entry.stepText || "Conversion…")}</span><div class="cv-jauge ${pending}"><i ${barStyle}></i></div></div>`
  }
  if (entry.status === "termine" && entry.confirmDelete) {
    return `<span class="cv-confirmer"><span class="cv-erreur">Supprimer ?</span><button type="button" class="cv-bouton cv-danger" data-supprimer-oui="${entry.id}">Oui</button><button type="button" class="cv-bouton" data-supprimer-non="${entry.id}">Non</button></span>`
  }
  if (entry.status === "termine") {
    const first  = entry.outputs[0]
    const more   = entry.outputs.length > 1 ? `<span class="cv-doux cv-mono" title="${entry.outputs.length} fichiers">${entry.outputs.length}</span>` : ""
    const remove = `<button type="button" class="cv-poubelle" data-supprimer="${entry.id}" aria-label="Supprimer le fichier converti" title="Supprimer le fichier converti (corbeille d'Obsidian)">${icon("trash", 14)}</button>`
    return `<span style="color:#8be8b0;display:flex">${icon("check", 15)}</span><a data-ouvrir="${escapeHtml(first)}">Ouvrir</a><a data-montrer="${escapeHtml(first)}">Dossier</a>${more}${remove}`
  }
  if (entry.status === "erreur") return `<span class="cv-erreur" title="${escapeHtml(entry.error)}">${escapeHtml(entry.error)}</span><button type="button" class="cv-bouton" data-convertir="${entry.id}">Réessayer</button>`
  return `<button type="button" class="cv-bouton" data-convertir="${entry.id}">Convertir</button>`
}


function renderRow(context, entry) {
  const kind      = KINDS[entry.detection.kind]
  const rowClass  = entry.status === "termine" ? "cv-fait" : entry.status === "erreur" ? "cv-echec" : ""
  const origin    = entry.source === "inbox" ? "Inbox" : ""
  const details   = [entry.details, origin].filter(Boolean).join(" · ")
  const removable = entry.status !== "en-cours"
  return `<div class="cv-ligne ${rowClass}" data-ligne="${entry.id}">
    ${renderTile(entry)}
    <span class="cv-fichier"><b title="${escapeHtml(entry.name)}">${escapeHtml(entry.name)}</b><span>${escapeHtml(details || formatSize(entry.size))}</span></span>
    <span class="cv-type" style="background:${kind.background};color:${kind.color}">${escapeHtml(kind.label)}</span>
    <span class="cv-taille cv-mono">${escapeHtml(formatSize(entry.size))}</span>
    <span class="cv-fleche">${icon("arrow", 14)}</span>
    <div class="cv-cible">${renderTarget(context, entry)}</div>
    <div class="cv-action">${renderAction(entry)}</div>
    ${removable ? `<button type="button" class="cv-retirer" data-retirer="${entry.id}" aria-label="Retirer ${escapeHtml(entry.name)} de la liste" title="Retirer de la liste (le fichier n'est pas supprimé)">${icon("close", 14)}</button>` : "<span></span>"}
  </div>`
}


function renderList(context) {
  const root       = context.root
  const holder     = root.querySelector("[data-liste]")
  if (!holder) return
  const entries    = context.entries
  const visible    = filterEntries(context)
  const counts     = Object.fromEntries(FILTERS.map(filter => [filter.id, filter.id === "tous" ? entries.length : entries.filter(entry => KINDS[entry.detection.kind].category === filter.id).length]))
  const fromInbox  = entries.filter(entry => entry.source === "inbox" && entry.status === "attente").length
  const waiting    = visible.filter(entry => entry.status === "attente" || entry.status === "erreur").length
  const busy       = entries.some(entry => entry.status === "en-cours")
  const imageCount = entries.filter(entry => (entry.detection.kind === "image" || entry.detection.kind === "svg") && (entry.status === "attente" || entry.status === "erreur")).length
  const pdfCount   = entries.filter(entry => entry.detection.kind === "pdf" && (entry.status === "attente" || entry.status === "erreur")).length
  const finished   = entries.filter(entry => entry.status === "termine" || entry.status === "impossible").length

  const tabs = FILTERS.map(filter => {
    const button  = `<button type="button" class="cv-onglet ${context.filter === filter.id ? "cv-actif" : ""}" data-filtre="${filter.id}" ${CATEGORY_SOURCES[filter.id] ? `aria-describedby="cv-infobulle-${filter.id}"` : ""}>${filter.label}<span class="cv-mono">${counts[filter.id]}</span></button>`
    const tooltip = renderConversionTooltip(context, filter.id)
    return tooltip ? `<span class="cv-onglet-bloc">${button}${tooltip}</span>` : button
  }).join("")
  const groupButtons = [
    imageCount >= 2 ? `<button type="button" class="cv-bouton" data-groupe="images" ${busy ? "disabled" : ""}>Assembler ${imageCount} images en un PDF</button>` : "",
    pdfCount >= 2 ? `<button type="button" class="cv-bouton" data-groupe="pdf" ${busy ? "disabled" : ""}>Fusionner ${pdfCount} PDF</button>` : ""
  ].join("")
  const header = `<div class="cv-ligne cv-titres"><span></span><span>Fichier</span><span>Type</span><span>Taille</span><span></span><span>Convertir en</span><span></span><span></span></div>`
  const rows   = visible.map(entry => renderRow(context, entry)).join("")
  const empty  = `<div class="cv-vide"><span class="cv-logo" style="width:46px;height:46px;border-radius:13px">${icon("upload", 22)}</span><b>${entries.length ? "Aucun fichier de ce type" : "Aucun fichier à convertir"}</b><span class="cv-doux">Dépose des fichiers ici, choisis-les avec « parcourir », ou mets-les dans « ${escapeHtml(INBOX_FOLDER)} ».</span></div>`

  holder.innerHTML = `
    <div class="cv-barre">
      ${tabs}
      <div style="flex:1"></div>
      ${fromInbox ? `<span class="cv-doux">${fromInbox} ${fromInbox > 1 ? "viennent" : "vient"} de l'Inbox</span>` : ""}
      ${finished ? `<button type="button" class="cv-lien" data-action="nettoyer">Retirer les terminés</button>` : ""}
      ${groupButtons}
      <button type="button" class="cv-bouton cv-principal" data-action="tout" ${waiting && !busy ? "" : "disabled"}>Tout convertir${waiting ? " (" + waiting + ")" : ""}</button>
    </div>
    ${visible.length ? header + rows : empty}`
  bindListEvents(context)
}


function bindListEvents(context) {
  const holder = context.root.querySelector("[data-liste]")
  const findEntry = id => context.entries.find(entry => entry.id === Number(id))
  holder.querySelectorAll("[data-filtre]").forEach(button => button.addEventListener("click", () => {
    context.filter = button.getAttribute("data-filtre")
    renderList(context)
  }))
  holder.querySelectorAll("[data-cible]").forEach(select => select.addEventListener("change", () => {
    const entry  = findEntry(select.getAttribute("data-cible"))
    entry.target = select.value
    renderList(context)
  }))
  holder.querySelectorAll("[data-pages]").forEach(input => input.addEventListener("input", () => {
    const entry = findEntry(input.getAttribute("data-pages"))
    entry.pages = input.value
  }))
  holder.querySelectorAll("[data-convertir]").forEach(button => button.addEventListener("click", () => convertEntry(context, findEntry(button.getAttribute("data-convertir")))))
  holder.querySelectorAll("[data-retirer]").forEach(button => button.addEventListener("click", () => {
    const id = Number(button.getAttribute("data-retirer"))
    const entry = findEntry(id)
    if (entry && entry.objectUrl) URL.revokeObjectURL(entry.objectUrl)
    context.entries = context.entries.filter(candidate => candidate.id !== id)
    if (entry && entry.source === "inbox" && entry.status === "attente") context.ignored.add(entry.path)
    renderList(context)
  }))
  holder.querySelectorAll("[data-supprimer]").forEach(button => button.addEventListener("click", () => {
    const entry = findEntry(button.getAttribute("data-supprimer"))
    entry.confirmDelete = true
    renderList(context)
  }))
  holder.querySelectorAll("[data-supprimer-non]").forEach(button => button.addEventListener("click", () => {
    const entry = findEntry(button.getAttribute("data-supprimer-non"))
    entry.confirmDelete = false
    renderList(context)
  }))
  holder.querySelectorAll("[data-supprimer-oui]").forEach(button => button.addEventListener("click", () => deleteConverted(context, findEntry(button.getAttribute("data-supprimer-oui")))))
  holder.querySelectorAll("[data-ouvrir]").forEach(link => link.addEventListener("click", () => openPath(context, link.getAttribute("data-ouvrir"))))
  holder.querySelectorAll("[data-montrer]").forEach(link => link.addEventListener("click", () => revealPath(context, link.getAttribute("data-montrer"))))
  holder.querySelector("[data-action=tout]")?.addEventListener("click", () => convertVisible(context))
  holder.querySelector("[data-action=nettoyer]")?.addEventListener("click", () => {
    context.entries = context.entries.filter(entry => entry.status !== "termine" && entry.status !== "impossible")
    renderList(context)
  })
  holder.querySelector("[data-groupe=images]")?.addEventListener("click", () => convertGroup(context, entry => entry.detection.kind === "image" || entry.detection.kind === "svg", context.engine.assembleImages, " - images"))
  holder.querySelector("[data-groupe=pdf]")?.addEventListener("click", () => convertGroup(context, entry => entry.detection.kind === "pdf", context.engine.mergePdfs, " - fusion"))
}


function renderFooter(context) {
  const footer = context.root.querySelector("[data-pied]")
  const keep   = context.settings.conserverOriginaux
  const help   = keep ? "Activé : l'original est rangé dans « Originaux »." : "Désactivé : seul le fichier converti est gardé (l'original de l'Inbox part dans la corbeille d'Obsidian)."
  footer.innerHTML = `
    <span class="cv-reglage"><button type="button" class="cv-interrupteur ${keep ? "cv-actif" : ""}" role="switch" aria-checked="${keep}" aria-label="Conserver les originaux" data-action="originaux"><i></i></button>Conserver les originaux</span>
    <span class="cv-doux">${escapeHtml(help)}</span>
    <span class="cv-statut" data-statut></span>
    <div style="flex:1"></div>
    <button type="button" class="cv-lien" data-dossier="${escapeHtml(OUTPUT_FOLDER)}">Convertis</button>
    <button type="button" class="cv-lien" data-dossier="${escapeHtml(ORIGINALS_FOLDER)}">Originaux</button>`
  footer.querySelector("[data-action=originaux]").addEventListener("click", async () => {
    context.settings.conserverOriginaux = !context.settings.conserverOriginaux
    await writeJson(SETTINGS_PATH, context.settings)
    renderFooter(context)
  })
  footer.querySelectorAll("[data-dossier]").forEach(button => button.addEventListener("click", () => openFolder(context, button.getAttribute("data-dossier"))))
}


function setStatus(context, message) {
  const status = context.root.querySelector("[data-statut]")
  if (status) status.textContent = message ?? ""
}


function renderShell(context) {
  const root = context.root
  root.innerHTML = `
    <header class="cv-verre cv-entete">
      <span class="cv-logo">${icon("logo", 18)}</span>
      <span class="cv-nom">Convertisseur</span>
      <label class="cv-depot" tabindex="0">
        ${icon("upload", 17)}
        <span class="cv-texte-large">Dépose des fichiers ici, ou <b>parcourir</b> · images, photos HEIC, PDF, Word, notes, HTML, CSV, Excel, JSON</span>
        <span class="cv-texte-court"><b>Choisir des fichiers</b></span>
        <input type="file" multiple data-action="choisir" style="display:none">
      </label>
      <button type="button" class="cv-bouton cv-icone" data-action="actualiser" aria-label="Relire l'Inbox" title="Relire l'Inbox">${icon("refresh", 16)}</button>
      <button type="button" class="cv-bouton cv-icone" data-action="fond" aria-label="Fond et transparence" title="Fond et transparence" aria-haspopup="dialog">${icon("image", 16)}</button>
    </header>
    <section class="cv-verre cv-liste-carte" style="display:flex;flex-direction:column">
      <div data-liste></div>
      <div class="cv-pied" data-pied></div>
    </section>`

  root.querySelector("[data-action=choisir]").addEventListener("change", async event => {
    const input = event.target
    await addFiles(context, input.files)
    input.value = ""
  })
  root.querySelector(".cv-depot").addEventListener("keydown", event => {
    if (event.key === "Enter" || event.key === " ") { event.preventDefault(); root.querySelector("[data-action=choisir]").click() }
  })
  root.querySelector("[data-action=actualiser]").addEventListener("click", async () => {
    context.ignored.clear()
    await refreshInbox(context)
  })
  root.querySelector("[data-action=fond]").addEventListener("click", () => openAppearancePanel(context))
  bindDropZone(context)
}


async function addFiles(context, fileList) {
  const count = fileList ? fileList.length : 0
  if (!count) return
  setStatus(context, "Lecture de " + count + " fichier(s)…")
  await addExternalFiles(context, fileList)
  setStatus(context, "")
  renderList(context)
}


async function refreshInbox(context) {
  await scanInbox(context)
  context.entries = context.entries.filter(entry => !(entry.source === "inbox" && entry.status === "attente" && context.ignored.has(entry.path)))
  renderList(context)
}


function bindDropZone(context) {
  const root = context.root
  let depth  = 0
  const hasFiles = event => Array.from(event.dataTransfer?.types ?? []).includes("Files")
  root.addEventListener("dragenter", event => {
    if (!hasFiles(event)) return
    event.preventDefault()
    event.stopPropagation()
    depth++
    root.classList.add("cv-glisse")
  }, true)
  root.addEventListener("dragover", event => {
    if (!hasFiles(event)) return
    event.preventDefault()
    event.stopPropagation()
    event.dataTransfer.dropEffect = "copy"
  }, true)
  root.addEventListener("dragleave", event => {
    if (!hasFiles(event)) return
    depth = Math.max(0, depth - 1)
    if (depth === 0) root.classList.remove("cv-glisse")
  }, true)
  root.addEventListener("drop", async event => {
    if (!hasFiles(event)) return
    event.preventDefault()
    event.stopPropagation()
    depth = 0
    root.classList.remove("cv-glisse")
    await addFiles(context, event.dataTransfer.files)
  }, true)
}


function removeStaleStyles() {
  document.querySelectorAll("style").forEach(element => {
    if (element.textContent.includes(".cv-app {")) element.remove()
  })
}


function watchVisibility(context) {
  const CHECK_MILLISECONDS = 5000
  const timer = setInterval(() => {
    if (context.root.isConnected) return
    clearInterval(timer)
    const visibleApp = document.querySelector(".markdown-preview-view .cv-app")
    if (!visibleApp) closeModal(context, false)
  }, CHECK_MILLISECONDS)
}


// ---------- Démarrage ----------

removeStaleStyles()
const container   = dv.container
const viewElement = container.closest(".markdown-preview-view")
container.createEl("style", { text: STYLE })
const root        = container.createDiv({ cls: "cv-app" })
const context     = window.cvContexte ?? { entries: [], lastId: 0, filter: "tous", modal: null, modalKeys: null, ignored: new Set() }
window.cvContexte   = context
context.root        = root
context.viewElement = viewElement
context.modules     = getNodeModules()
context.appearance  = Object.assign({}, DEFAULT_APPEARANCE, await readJson(APPEARANCE_PATH, {}))
context.settings    = Object.assign({}, DEFAULT_SETTINGS, await readJson(SETTINGS_PATH, {}))
context.engine      = await loadEngine()

renderShell(context)
renderFooter(context)
await applyAppearance(context)
await refreshInbox(context)
watchVisibility(context)
